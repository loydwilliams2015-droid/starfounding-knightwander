# SCALE/ART QA-003 — S14 Profile A selected, revised

Append-only amendment. **Active influences: Mega Man X4 (strong, decisive poses) and Dead Cells (selective animation continuity).** Yoshi, Kirby, and Tales of Phantasia remain bracketed out. No copyrighted game images or ripped sprites are included.

## Experiment
At 60 presentation frames per second, compare S13 A `[0,0,1,3,3,3,3,3]` with S14 refined A `[0,0,1,2,3,3,3,3]` using original reference sprites: stand, settle, compress, crouch. Each frame is 16.67 ms, 8 sampled frames span a 133 ms schedule. This is a sampling convention, **not** a measured in-game input-latency claim.

S14 retains rapid key-pose emphasis but dedicates one frame to compression rather than skipping its illustration. Both samples end in the same crouched image and use the same bottom-center pivot. Both are proof-of-concept timing studies, not final animation. No change to authoritative collider / input handling.

## Acceptance boundaries
* Automated: pose indices in range and monotonic; frame assets nonempty and 64 px wide; 1:1 scale; fixed foot anchor; existing collision and input suites pass.
* Human review still OPEN: silhouette precision, material coherence, foot slide, expressive motion, gameplay-distance legibility, and actual SK game integration.
* Never certify original game's production sprite from these reference-only pixels.

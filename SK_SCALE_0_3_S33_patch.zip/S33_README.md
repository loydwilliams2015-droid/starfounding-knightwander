# SK SCALE/ART S33 — Recoverability gate

This is the **standalone Godot SCALE/ART QA prototype**, not the original full Starfounding Knightwander game. S33 preserves the exact S32 source tree, adds a per-file SHA-256 inventory and an isolated restore/test tool. It does not alter approved sprites, movement, collision, or animation.

To verify a canonical S32 archive, run `python3 tools/s33_restore_verify.py SK_SCALE_0_3_S32_patch.zip --godot /path/to/godot`. It extracts into a disposable directory, imports Godot resources, runs seven headless native tests and removes the extraction. The original project is never overwritten.

`S33_FILE_MANIFEST.json` lists every restored original file byte size and SHA-256. `S33_VERIFICATION.json` records this session's actual results. The canonical source S32 ZIP hash is `556bdb4e1370306cdbcfc3777bf24ec7b060fca5d772bd3eb24461c5b4437b0b`.

**GitHub recovery caveat:** The repository must contain the *actual source bytes*, not just the hash, for full cross-chat backup. This S33 ZIP is a conversation artifact until those bytes are uploaded and GitHub confirms them.

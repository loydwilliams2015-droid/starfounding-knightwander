# SK SCALE/ART QA-011 — S22 key-pose continuity experiment

Append-only follow-up to QA-010. **Profile A retained** (Mega Man X4 deliberate key poses, Dead Cells-inspired continuity only when it serves readability). Reference images remain original SK experiments, never extracted from either game.

- Compare S21 settling/S20 compression **control** against new S22 settling/compression **trial** with exactly the same [0,0,1,2,3,3,3,3] visual schedule.
- Verify full-size texture selection, bottom-center foot origin, identical base crouching art, true horizontal flip, nearest-neighbor sampling, and alpha-safe dimensions.
- Review knee/hip bending, belt/hand continuity, and silhouette at ordinary 1× capture, not solely enlarged.
- Test against the original procedural stone-and-foliage QA backdrop. This comparison cannot certify full-game background readability.
- No visual interpolation may modify SKCrouchAdapter collision shapes. Never silently replace the approved production asset.
- Require human visual acceptance before promoting trial art; original SK project integration still open.

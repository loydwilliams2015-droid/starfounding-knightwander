# SCALE/ART QA-018 — Vertical framing and jump visibility

Append-only S30 amendment. S29 horizontal look-ahead and S27 manual camera phase retain ownership. Vertical camera look-ahead is an optional QA feature, not an adopted SK production-camera setting.

- Ascending motion: camera offset trends toward -46 world px (rising scene anticipation).
- Descending motion: camera offset trends toward +64 world px.
- Grounded: return smoothly to zero.
- Camera offset remains pixel-rounded; never scale the knight sprite or collider.
- Test 960×540 engine renders during rise, apex, fall, landing and recentering.
- References: Mega Man X4 for response clarity; Dead Cells for restrained environmental depth.
- Gate: tests pass AND evidence rendered; user art-quality and original-game integration remain independent.

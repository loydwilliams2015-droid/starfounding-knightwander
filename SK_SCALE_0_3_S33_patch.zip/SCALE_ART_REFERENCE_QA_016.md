# QA-016 — S28 Player-driven parallax acceptance (append-only)

- PASS: horizontal action advances actor and attached camera while four Parallax2D scroll factors stay monotonic.
- PASS: actual jump impulse and airborne displacement; landing resolves against collision geometry.
- PASS: crouch-running retains crouch artwork, expected collider dimensions and overlay integrity.
- PASS: background architecture and foreground remain decoratively subdued while platforms retain collision.
- EVIDENCE: 14 discrete Godot-rendered 960×540 frames and screenshot-derived GIF.
- OPEN: sustained player-input performance profiling; full-game integration; art approval; human judgements of scrolling stability; production-resolution camera settings.

These checks evaluate function, not a subjective A-grade or final art certification. Existing QA-001 through QA-015 are retained unchanged.

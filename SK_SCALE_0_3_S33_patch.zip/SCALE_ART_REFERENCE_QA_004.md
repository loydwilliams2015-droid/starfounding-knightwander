# SCALE/ART QA-004 — S15 moving-pose study (append-only)

Decision remains **A over B**. Active references are *Mega Man X4* (deliberate key silhouettes) and *Dead Cells* (selected continuity techniques). This reference study uses entirely original SK QA artwork; commercial game graphics are not redistributed. Yoshi, Kirby, and Tales of Phantasia remain outside the active rubric.

## Measurable acceptance
- Exact source textures, bottom-center foot anchors, and 1:1 scale remain invariant during both directional studies.
- Horizontal facing uses Sprite2D.flip_h rather than geometry inversion.
- Profile A's single-frame intermediate compression is preserved on crouching and on standing recovery in the new visual sequence.
- Crouching collision authority and input remain owned by the existing adapter/controller.
- Automated checks certify technical invariants, **not** pose appeal or absence of perceived sliding. Human art review is required before production-art acceptance.

## Evidence limits
The S15 motion GIF is an ordered set of actual Godot screenshots from a scripted *review scene*, not continuous player-input gameplay footage. Each figure's screen position is authored by the capture script; it is not proof of movement collision performance. Reference sprites remain unapproved.

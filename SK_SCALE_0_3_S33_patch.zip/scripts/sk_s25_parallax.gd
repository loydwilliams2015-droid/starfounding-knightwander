extends Node2D
## Original SK S25 procedural parallax matte. Decorative only: no gameplay or collision authority.
@export var layer_kind: int = 0
@export var seed_offset: int = 0
const W := 1800
func _ready() -> void:
    z_index = 8 if layer_kind == 4 else (-20 + layer_kind)
    queue_redraw()
func _draw() -> void:
    match layer_kind:
        0:
            draw_rect(Rect2(-400,-800,2500,1550), Color("111b37"))
            for n in range(70):
                var x := float(((n*247+43)%2200)-320)
                var y := float(((n*117+19)%420)-640)
                var radius := 1.0 if n%5 else 2.0
                draw_circle(Vector2(x,y),radius,Color("738cb1",0.65))
            draw_circle(Vector2(740,-370),54,Color("bdc4be",0.85))
            draw_circle(Vector2(757,-385),51,Color("111b37"))
        1:
            var points := PackedVector2Array()
            points.append(Vector2(-500,600))
            for i in range(0,23):
                var x := -500.0+float(i)*105.0
                var y := -130.0+sin(float(i)*1.29)*56.0+cos(float(i)*0.54)*32.0
                points.append(Vector2(x,y))
            points.append(Vector2(2000,600))
            draw_colored_polygon(points,Color("203452"))
        2:
            for i in range(-3,23):
                var x := float(i*100)
                var top := -40.0+float((i*37)%4)*27.0
                draw_rect(Rect2(x,top,80,520),Color("294657"))
                draw_rect(Rect2(x+8,top-12,63,12),Color("415d69"))
                for j in range(4):
                    var wy := top+31.0+float(j)*65.0
                    draw_rect(Rect2(x+18,wy,11,21),Color("a69b66",0.65 if (i+j)%3 else 0.20))
                    draw_rect(Rect2(x+50,wy,11,21),Color("a69b66",0.3 if (i+j)%2 else 0.72))
        3:
            for i in range(-4,30):
                var x := float(i*71)
                var y := 375.0+sin(float(i)*0.76)*13.0
                draw_line(Vector2(x,y),Vector2(x-12,y-110),Color("183b45"),9.0)
                for p in range(3):
                    draw_circle(Vector2(x-25+float(p)*21,y-108-float(p%2)*22),29,Color("285755",0.82))
        4:
            for i in range(-4,28):
                var x := float(i*83)
                draw_rect(Rect2(x,438,75,7),Color("586774"))
                draw_line(Vector2(x+3,440),Vector2(x+37,463),Color("85928c",0.4),2.0)

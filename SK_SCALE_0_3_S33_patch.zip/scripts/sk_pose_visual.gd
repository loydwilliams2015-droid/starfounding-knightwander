class_name SKPoseVisual
extends Sprite2D
## SCALE/ART S11: enforce all render-facing pose invariants, including anchors.
## The Sprite2D origin is the body's foot anchor. Do not squash the standing pose.
@export var standing_texture: Texture2D = preload("res://assets/knight_standing.png")
@export var crouching_texture: Texture2D = preload("res://assets/knight_crouching.png")
var crouched: bool = false
var facing_left: bool = false
signal pose_applied(is_crouched: bool, assigned_texture: Texture2D)

func _ready() -> void:
    assert(standing_texture != null and crouching_texture != null, "Both pose textures are required")
    assert(standing_texture != crouching_texture, "Separate authored crouch texture required")
    texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
    centered = true
    region_enabled = false
    _apply_pose()

func set_crouched(value: bool) -> void:
    if crouched == value and pose_texture_verified():
        return
    crouched = value
    _apply_pose()

func pose_texture_verified() -> bool:
    var expected: Texture2D = crouching_texture if crouched else standing_texture
    return (texture != null and texture == expected and scale == Vector2.ONE
        and centered and not region_enabled
        and offset.is_equal_approx(Vector2(0.0, -float(expected.get_height()) * 0.5))
        and flip_h == facing_left
        and texture_filter == CanvasItem.TEXTURE_FILTER_NEAREST)

func repair_pose_texture() -> bool:
    # Safe for third-party animation, customization, or a stale texture override.
    if not pose_texture_verified():
        _apply_pose()
    return pose_texture_verified()

func set_facing_left(value: bool) -> void:
    facing_left = value
    flip_h = value  # Never mirror via scale.x: preserve 1:1 geometry and anchors.

func current_asset_path() -> String:
    # Resolve the texture in the renderer, not a label derived from pose state.
    # Imported/overridden textures can otherwise appear correctly while HUD lies.
    if texture == null:
        return "[missing texture]"
    var path: String = texture.resource_path
    return path if not path.is_empty() else "[embedded texture: %s]" % texture.get_rid()

func _apply_pose() -> void:
    var selected: Texture2D = crouching_texture if crouched else standing_texture
    if selected == null:
        push_error("SCALE/ART: missing texture for requested pose")
        return
    assert(selected.get_width() > 0 and selected.get_height() > 0, "Pose texture cannot be empty")
    texture = selected
    assert(texture == selected, "Assigned pose texture must equal selected resource")
    centered = true
    region_enabled = false
    scale = Vector2.ONE
    offset = Vector2(0.0, -float(texture.get_height()) * 0.5)
    flip_h = facing_left
    texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
    pose_applied.emit(crouched, selected)

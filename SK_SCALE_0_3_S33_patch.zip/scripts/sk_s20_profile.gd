class_name SKS20Profile
extends RefCounted
## Original SK reference-only art comparison; no collider or gameplay state authority.
const BASE = preload("res://assets/knight_transition_compress.png")
const S19 = preload("res://assets/knight_transition_compress_s19_trial.png")
const S20 = preload("res://assets/knight_transition_compress_s20_narrow.png")
const STAND = preload("res://assets/knight_standing.png")
const SETTLE = preload("res://assets/knight_transition_settle.png")
const CROUCH = preload("res://assets/knight_crouching.png")
const FRAME_STATES: Array[int] = [0, 0, 1, 2, 3, 3, 3, 3]
static func select(frame: int, candidate: int) -> Texture2D:
    match FRAME_STATES[clampi(frame, 0, 7)]:
        0: return STAND
        1: return SETTLE
        2:
            match candidate:
                0: return BASE
                1: return S19
                _: return S20
        _: return CROUCH
static func show_pose(sprite: Sprite2D, frame: int, candidate: int, facing_left: bool) -> void:
    var tex := select(frame, candidate)
    sprite.texture=tex
    sprite.centered=true
    sprite.region_enabled=false
    sprite.offset=Vector2(0.0,-float(tex.get_height())/2.0)
    sprite.scale=Vector2.ONE
    sprite.flip_h=facing_left
    sprite.texture_filter=CanvasItem.TEXTURE_FILTER_NEAREST

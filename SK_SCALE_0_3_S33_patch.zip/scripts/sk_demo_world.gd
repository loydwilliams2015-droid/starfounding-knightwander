extends Node2D
## S10: reproducible action-based controls. This is a standalone SCALE/ART QA scene.
## A/D or arrows: move; Ctrl/Down: crouch; Space: jump; R: restart.
const POSE_SCRIPT = preload("res://scripts/sk_pose_visual.gd")
const CROUCH_SCRIPT = preload("res://scripts/sk_crouch_adapter.gd")
var actor: CharacterBody2D
var adapter: SKCrouchAdapter
var hud: Label
var jump_queued := false
var art_driver: SKS23VisualDriver
var physics_steps: int = 0

static func ensure_input_actions() -> void:
    var actions := {
        "sk_left": [KEY_A, KEY_LEFT],
        "sk_right": [KEY_D, KEY_RIGHT],
        "sk_crouch": [KEY_CTRL, KEY_DOWN],
        "sk_jump": [KEY_SPACE]
    }
    for action in actions:
        if not InputMap.has_action(action):
            InputMap.add_action(action)
        for key in actions[action]:
            var ev := InputEventKey.new()
            ev.physical_keycode = key
            if not InputMap.action_has_event(action, ev):
                InputMap.action_add_event(action, ev)

func _ready() -> void:
    ensure_input_actions()
    _add_platform(Vector2(480, 495), Vector2(960, 90), Color("28383d"))
    _add_platform(Vector2(720, 350), Vector2(420, 60), Color("536d75"))
    actor = CharacterBody2D.new()
    actor.name = "Knight"
    actor.position = Vector2(190, 450)
    actor.collision_layer = 1
    actor.collision_mask = 1
    add_child(actor)
    var shape := CollisionShape2D.new()
    shape.name = "FootAnchoredCollider"
    actor.add_child(shape)
    var sprite := Sprite2D.new()
    sprite.name = "KnightPose"
    sprite.set_script(POSE_SCRIPT)
    actor.add_child(sprite)
    var crouch_node := Node.new()
    crouch_node.name = "SKCrouchAdapter"
    crouch_node.set_script(CROUCH_SCRIPT)
    crouch_node.set("body", actor)
    crouch_node.set("collider", shape)
    crouch_node.set("visual", sprite)
    actor.add_child(crouch_node)
    adapter = crouch_node as SKCrouchAdapter
    # S23: draw authored key poses independently from authoritative pose/collision.
    art_driver = SKS23VisualDriver.new()
    art_driver.name = "S23VisualDriver"
    art_driver.adapter = adapter
    art_driver.source_sprite = sprite
    actor.add_child(art_driver)
    var canvas := CanvasLayer.new()
    add_child(canvas)
    hud = Label.new()
    hud.position = Vector2(20, 16)
    hud.add_theme_font_size_override("font_size", 16)
    canvas.add_child(hud)
    queue_redraw()

func _add_platform(center: Vector2, dimensions: Vector2, color: Color) -> void:
    var block := StaticBody2D.new()
    block.position = center
    block.collision_layer = 1
    block.collision_mask = 0
    add_child(block)
    var collider := CollisionShape2D.new()
    var rect := RectangleShape2D.new()
    rect.size = dimensions
    collider.shape = rect
    block.add_child(collider)
    var art := Polygon2D.new()
    var w := dimensions.x * 0.5
    var h := dimensions.y * 0.5
    art.polygon = PackedVector2Array([Vector2(-w,-h),Vector2(w,-h),Vector2(w,h),Vector2(-w,h)])
    art.color = color
    block.add_child(art)

func _unhandled_input(event: InputEvent) -> void:
    if event is InputEventKey and event.pressed and not event.echo and event.keycode == KEY_R:
        get_tree().reload_current_scene()

func _physics_process(delta: float) -> void:
    physics_steps += 1
    adapter.request_crouch(Input.is_action_pressed("sk_crouch"))
    var direction := Input.get_axis("sk_left", "sk_right")
    if absf(direction) > 0.001:
        adapter.visual.set_facing_left(direction < 0.0)
    actor.velocity.x = direction * (135.0 if adapter.crouched else 220.0)
    if not actor.is_on_floor():
        actor.velocity.y += 1050.0 * delta
    if (jump_queued or Input.is_action_just_pressed("sk_jump")) and actor.is_on_floor() and not adapter.crouched:
        actor.velocity.y = -410.0
    jump_queued = false
    actor.move_and_slide()
    hud.text = "SK SCALE/ART S23 | PROFILE A QA\nA/D move  Ctrl/Down crouch  Space jump  R restart\nPose %s | X %.1f | feet %.1f | blocked %s | actual texture %s\nArt verified %s | Geometry verified %s | reference art ONLY | visible %s" % ["CROUCH" if adapter.crouched else "STAND", actor.global_position.x, actor.global_position.y, str(adapter.stand_blocked), adapter.visual.current_asset_path(), str(adapter.visual.pose_texture_verified()), str(adapter.pose_geometry_verified()), art_driver.overlay.texture.resource_path.get_file() if art_driver.overlay != null else "NONE"]

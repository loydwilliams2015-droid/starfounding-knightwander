class_name SKS21Profile
extends RefCounted
## Visual-only experiment. No physics or controller authority.
const STAND = preload("res://assets/knight_standing.png")
const SETTLE_A = preload("res://assets/knight_transition_settle.png")
const SETTLE_B = preload("res://assets/knight_transition_settle_s21_trial.png")
const COMPRESS = preload("res://assets/knight_transition_compress_s20_narrow.png")
const CROUCH = preload("res://assets/knight_crouching.png")
const FRAMES: Array[int] = [0,0,1,2,3,3,3,3]
static func select(frame:int, variant:int) -> Texture2D:
    match FRAMES[clampi(frame,0,7)]:
        0: return STAND
        1: return SETTLE_A if variant==0 else SETTLE_B
        2: return COMPRESS
        _: return CROUCH
static func assign(sprite:Sprite2D, frame:int, variant:int, left:bool) -> void:
    var texture:=select(frame, variant)
    sprite.texture=texture
    sprite.centered=true
    sprite.region_enabled=false
    sprite.offset=Vector2(0,-texture.get_height()/2.0)
    sprite.scale=Vector2.ONE
    sprite.flip_h=left
    sprite.texture_filter=CanvasItem.TEXTURE_FILTER_NEAREST

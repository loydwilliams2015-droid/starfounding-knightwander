class_name SKCrouchAdapter
extends Node
## S8 additive pose/collision adapter. The existing controller owns movement/input.
## Feet are at CharacterBody2D local origin; no scale tricks or second controller.

@export var body: CharacterBody2D
@export var collider: CollisionShape2D
@export var visual: SKPoseVisual
@export var standing_height: float = 120.0
@export var crouched_height: float = 67.2
@export var collider_width: float = 52.0
@export_range(0.0, 8.0, 0.5) var headroom_padding: float = 2.0

var crouched: bool = false
var stand_blocked: bool = false

func _ready() -> void:
    assert(body != null and collider != null and visual != null)
    assert(standing_height > crouched_height and crouched_height > 0.0)
    assert(collider_width > 0.0)
    assert(is_zero_approx(body.rotation) and body.scale.is_equal_approx(Vector2.ONE), "S4 demo expects an unscaled/unrotated body")
    # Shapes are owned by the actor instance, never shared among characters.
    collider.shape = RectangleShape2D.new()
    _set_pose(false)

func request_crouch(want_crouch: bool) -> bool:
    # Refresh existing pose even when state does not change. Other game systems
    # can otherwise leave Sprite2D displaying stale or overridden artwork.
    visual.repair_pose_texture()
    repair_pose_geometry()
    if want_crouch:
        stand_blocked = false
        if not crouched:
            _set_pose(true)
        return true
    if not crouched:
        stand_blocked = false
        return true
    if not _can_stand():
        stand_blocked = true
        return false
    stand_blocked = false
    _set_pose(false)
    return true

func pose_geometry_verified() -> bool:
    # Separate collision truth from the visual sprite contract.
    var rect: RectangleShape2D = collider.shape as RectangleShape2D
    if rect == null:
        return false
    var expected_height: float = crouched_height if crouched else standing_height
    return (rect.size.is_equal_approx(Vector2(collider_width, expected_height))
        and collider.position.is_equal_approx(Vector2(0.0, -expected_height * 0.5)))

func repair_pose_geometry() -> bool:
    # Idempotent and safe only when this adapter owns the character's collider.
    # Do not replace the collider resource while the actor is in use.
    if not pose_geometry_verified():
        var rect: RectangleShape2D = collider.shape as RectangleShape2D
        if rect == null:
            push_error("SCALE/ART: unexpected non-rectangle collider")
            return false
        var height: float = crouched_height if crouched else standing_height
        rect.size = Vector2(collider_width, height)
        collider.position = Vector2(0.0, -height * 0.5)
    return pose_geometry_verified()

func _set_pose(value: bool) -> void:
    crouched = value
    var height: float = crouched_height if value else standing_height
    var rectangle: RectangleShape2D = collider.shape as RectangleShape2D
    rectangle.size = Vector2(collider_width, height)
    collider.position = Vector2(0.0, -height * 0.5)
    visual.set_crouched(value)

func _can_stand() -> bool:
    # Only the newly occupied upper slab is queried. Querying the entire
    # standing collider can produce ground-contact false positives.
    # A 1 px overlap with the current crouch box prevents a precision gap.
    var current_top: float = -crouched_height
    var target_top: float = -standing_height - headroom_padding
    var lower_edge: float = current_top + 1.0
    var slab_height: float = lower_edge - target_top
    if slab_height <= 0.0:
        return false
    var slab := RectangleShape2D.new()
    slab.size = Vector2(collider_width, slab_height)
    var query := PhysicsShapeQueryParameters2D.new()
    query.shape = slab
    query.transform = body.global_transform * Transform2D(0.0, Vector2(0.0, (target_top + lower_edge) * 0.5))
    query.collision_mask = body.collision_mask
    query.collide_with_bodies = true
    query.collide_with_areas = false
    query.exclude = [body.get_rid()]
    return body.get_world_2d().direct_space_state.intersect_shape(query, 1).is_empty()

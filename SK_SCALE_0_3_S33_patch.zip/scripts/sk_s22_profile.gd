class_name SKS22Profile
extends RefCounted
## Art-only: collision and input authority remain in SKCrouchAdapter/SKDemoWorld.
const STAND = preload("res://assets/knight_standing.png")
const SETTLE_CONTROL = preload("res://assets/knight_transition_settle_s21_trial.png")
const SETTLE_TRIAL = preload("res://assets/knight_transition_settle_s22_trial.png")
const COMPRESS_CONTROL = preload("res://assets/knight_transition_compress_s20_narrow.png")
const COMPRESS_TRIAL = preload("res://assets/knight_transition_compress_s22_trial.png")
const CROUCH = preload("res://assets/knight_crouching.png")
const FRAMES: Array[int] = [0,0,1,2,3,3,3,3]
static func select(frame:int, variant:int)->Texture2D:
    match FRAMES[clampi(frame,0,7)]:
        0: return STAND
        1: return SETTLE_CONTROL if variant == 0 else SETTLE_TRIAL
        2: return COMPRESS_CONTROL if variant == 0 else COMPRESS_TRIAL
        _: return CROUCH
static func assign(sprite:Sprite2D,frame:int,variant:int,left:bool)->void:
    var t:=select(frame,variant)
    sprite.texture=t
    sprite.centered=true
    sprite.region_enabled=false
    sprite.offset=Vector2(0,-float(t.get_height())*0.5)
    sprite.scale=Vector2.ONE
    sprite.flip_h=left
    sprite.texture_filter=CanvasItem.TEXTURE_FILTER_NEAREST

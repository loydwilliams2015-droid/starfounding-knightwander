extends Node2D
## S25 scene wrapper; leaves original S24 QA scene, adapter, and controller unchanged.
const DEMO = preload("res://scenes/sk_pose_demo.tscn")
const PARALLAX = preload("res://scripts/sk_s25_parallax.gd")
var demo: Node2D
var camera: Camera2D
var background_layers: Array[Parallax2D] = []
var foreground: Node2D
var lights: Array[PointLight2D] = []
var ready_frames: int = 0
var readability_mode: bool = false
var baseline_light_energies: Array[float] = []
func _ready() -> void:
    demo = DEMO.instantiate()
    demo.name = "VerifiedCharacterQA"
    add_child(demo)
    # S29 additive continuation: each platform overlaps its neighbor so there
    # are no cracks in the ground. The S28 platform and physics are untouched.
    for center_x in [1400.0, 2200.0, 3000.0]:
        demo._add_platform(Vector2(center_x,495),Vector2(900,90),Color("28383d"))
    # Collision-bearing raised surfaces are deliberately brighter than scenery.
    for center_x in [1310.0, 2070.0, 2770.0]:
        demo._add_platform(Vector2(center_x,290),Vector2(145,22),Color("788c90"))
    for i in range(4):
        var p := Parallax2D.new()
        p.name = ["DistantSky","MountainSilhouette","TownArchitecture","FoliageMidground"][i]
        p.scroll_scale = Vector2([0.03,0.16,0.38,0.70][i], [0.03,0.10,0.24,0.50][i])
        p.repeat_size = Vector2.ZERO
        p.z_index = -12+i
        add_child(p)
        move_child(p,0)
        var art := Node2D.new()
        art.set_script(PARALLAX)
        art.set("layer_kind",i)
        p.add_child(art)
        background_layers.append(p)
    foreground = Node2D.new()
    foreground.set_script(PARALLAX)
    foreground.set("layer_kind",4)
    foreground.z_index = 8
    demo.add_child(foreground)
    camera = Camera2D.new()
    camera.name = "SKTrackingCamera"
    camera.position = Vector2(0,-105)
    camera.zoom = Vector2.ONE
    camera.position_smoothing_enabled = false
    demo.actor.add_child(camera)
    camera.make_current()
    var light_texture := GradientTexture2D.new()
    light_texture.width = 256
    light_texture.height = 256
    light_texture.fill = GradientTexture2D.FILL_RADIAL
    light_texture.fill_from = Vector2(0.5,0.5)
    light_texture.fill_to = Vector2(0.5,0.0)
    var gradient := Gradient.new()
    gradient.set_color(0,Color(1.0,0.89,0.60,0.82))
    gradient.set_color(1,Color(1.0,0.7,0.3,0.0))
    light_texture.gradient = gradient
    for loc in [Vector2(300,350),Vector2(775,320)]:
        var lamp := PointLight2D.new()
        lamp.position = loc
        lamp.texture = light_texture
        lamp.texture_scale = 2.7
        lamp.energy = 0.9
        demo.add_child(lamp)
        lights.append(lamp)
        baseline_light_energies.append(lamp.energy)
    demo.hud.visible = false
    var canvas := CanvasLayer.new()
    canvas.name = "S25PresentationHUD"
    add_child(canvas)
    var heading := Label.new()
    heading.position = Vector2(16,12)
    heading.text = "STARFOUNDING KNIGHTWANDER  /  S30 vertical look-ahead QA"
    heading.add_theme_font_size_override("font_size",12)
    heading.add_theme_color_override("font_color",Color("e8ecd8"))
    canvas.add_child(heading)
func _process(_delta: float) -> void:
    ready_frames += 1
func set_preview(x: float,crouch: bool,zoom: float=1.0) -> void:
    demo.actor.global_position = Vector2(x,450)
    demo.actor.velocity = Vector2.ZERO
    camera.zoom = Vector2(zoom,zoom)
    if crouch:
        Input.action_press("sk_crouch")
    else:
        Input.action_release("sk_crouch")
    demo.adapter.request_crouch(crouch)
    demo.art_driver.phase = 7 if crouch else 0
    demo.art_driver.last_crouched = crouch
    demo.art_driver.frame_tick = 7
    demo.art_driver.active = false
    demo.art_driver._render_frame()

## S26 reversible environment-only grade: preserve Sprite2D, collision, parallax motion.
func set_readability_mode(enabled: bool) -> void:
    readability_mode = enabled
    # Push busy foliage away from the knight, keep full scene intact.
    background_layers[2].modulate.a = 0.82 if enabled else 1.0
    background_layers[3].modulate.a = 0.52 if enabled else 1.0
    foreground.modulate.a = 0.55 if enabled else 1.0
    for i in range(lights.size()):
        lights[i].energy = baseline_light_energies[i] * (0.85 if enabled else 1.0)


## S27 additive: the world and actor are unchanged; the camera is the sole moving
## viewport. Never scale the actor to approximate a camera movement.
var s27_camera_phase: float = 0.0
func set_camera_tracking_phase(phase: float, snap_to_pixel: bool = true) -> void:
    s27_camera_phase = phase
    # S27 diagnostic explicitly owns camera offset while enabled.
    s29_lookahead_enabled = false
    s30_vertical_enabled = false
    var offset_world := Vector2(phase, sin(phase / 110.0) * 2.0)
    camera.offset = offset_world.round() if snap_to_pixel else offset_world

func set_surface_separation(enabled: bool) -> void:
    # Decorative foreground should never be mistaken for collision terrain.
    foreground.modulate.a = 0.34 if enabled else (0.55 if readability_mode else 1.0)
    background_layers[2].modulate.a = 0.70 if enabled else (0.82 if readability_mode else 1.0)

## S28: data-oriented camera review. The camera remains attached to the actor;
## the helper only reads scene state and does not take over character controls.
func s28_camera_snapshot() -> Dictionary:
    return {
        "actor_world": demo.actor.global_position,
        "camera_world": camera.get_screen_center_position(),
        "camera_offset": camera.offset,
        "zoom": camera.zoom,
        "crouched": demo.adapter.crouched,
        "jump_velocity": demo.actor.velocity.y,
        "parallax_scales": [background_layers[0].scroll_scale.x, background_layers[1].scroll_scale.x, background_layers[2].scroll_scale.x, background_layers[3].scroll_scale.x]
    }

## S29: visual camera direction anticipates horizontal travel, never moves the
## actual player, modifies collider, or changes the world/parallax layer rates.
var s29_lookahead_enabled: bool = true
var s29_lookahead_x: float = 0.0
## S30 additive vertical framing: negative Y anticipates rising; positive Y anticipates falling.
## Manual S27 camera-phase captures remain authoritative until explicitly re-enabled.
var s30_vertical_enabled: bool = true
var s30_vertical_offset: float = 0.0
const S30_VERTICAL_UP_LIMIT := -46.0
const S30_VERTICAL_DOWN_LIMIT := 64.0
const S30_VERTICAL_RESPONSE := 5.0
const S29_MAX_LOOKAHEAD := 66.0
const S29_LOOKAHEAD_RESPONSE := 7.0
func _physics_process(delta: float) -> void:
    if demo == null or camera == null or not s29_lookahead_enabled:
        return
    var horizontal := Input.get_axis("sk_left","sk_right")
    var desired := horizontal * S29_MAX_LOOKAHEAD if s29_lookahead_enabled else 0.0
    var blend := 1.0 - exp(-S29_LOOKAHEAD_RESPONSE * delta)
    s29_lookahead_x = lerpf(s29_lookahead_x,desired,blend)
    camera.offset.x = roundf(s29_lookahead_x)
    if s30_vertical_enabled:
        var vy: float = demo.actor.velocity.y
        var desired_y: float = clampf(vy * 0.14, S30_VERTICAL_UP_LIMIT, S30_VERTICAL_DOWN_LIMIT) if not demo.actor.is_on_floor() else 0.0
        var alpha_y: float = 1.0 - exp(-S30_VERTICAL_RESPONSE * delta)
        s30_vertical_offset = lerpf(s30_vertical_offset,desired_y,alpha_y)
        camera.offset.y = roundf(s30_vertical_offset)

func s29_camera_diagnostics() -> Dictionary:
    return {
        "lookahead_x": s29_lookahead_x,
        "camera_offset_x": camera.offset.x,
        "actor_x": demo.actor.global_position.x,
        "ground_sections": 4,
        "raised_platform_sections": 3,
        "parallax_scales": [background_layers[0].scroll_scale.x,background_layers[1].scroll_scale.x,background_layers[2].scroll_scale.x,background_layers[3].scroll_scale.x]
    }

func s30_camera_diagnostics() -> Dictionary:
    return {
        "vertical_offset": s30_vertical_offset,
        "camera_offset_y": camera.offset.y,
        "airborne": not demo.actor.is_on_floor(),
        "velocity_y": demo.actor.velocity.y,
        "vertical_enabled": s30_vertical_enabled,
        "horizontal_offset": s29_lookahead_x,
        "parallax_count": background_layers.size()
    }

func set_s30_vertical_tracking(enabled: bool) -> void:
    s30_vertical_enabled = enabled
    if not enabled:
        s30_vertical_offset = 0.0
        camera.offset.y = 0.0

## S32: explicit transition from manual diagnostics to normal player-follow
## camera ownership. Idempotent; leaves world geometry and actor unchanged.
func set_s32_auto_camera_tracking(enabled: bool) -> void:
    if enabled:
        s29_lookahead_enabled = true
        s30_vertical_enabled = true
        s27_camera_phase = 0.0
        # Clear stale manual offsets; the next physics frame owns both axes.
        s29_lookahead_x = 0.0
        s30_vertical_offset = 0.0
        camera.offset = Vector2.ZERO
    else:
        s29_lookahead_enabled = false
        s30_vertical_enabled = false

func s32_camera_ownership_snapshot() -> Dictionary:
    return {
        "auto_horizontal": s29_lookahead_enabled,
        "auto_vertical": s30_vertical_enabled,
        "manual_phase": s27_camera_phase,
        "offset": camera.offset,
        "actor_position": demo.actor.global_position,
        "parallax_count": background_layers.size()
    }

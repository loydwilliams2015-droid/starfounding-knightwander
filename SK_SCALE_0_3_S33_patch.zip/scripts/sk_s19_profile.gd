class_name SKS19Profile
extends RefCounted
## Experimental visual-only Profile A study. Never touch collider authority.
const STAND: Texture2D = preload("res://assets/knight_standing.png")
const SETTLE: Texture2D = preload("res://assets/knight_transition_settle.png")
const BASE_COMPRESSION: Texture2D = preload("res://assets/knight_transition_compress.png")
const TRIAL_COMPRESSION: Texture2D = preload("res://assets/knight_transition_compress_s19_trial.png")
const CROUCH: Texture2D = preload("res://assets/knight_crouching.png")
const A_PROFILE: Array[int] = [0,0,1,2,3,3,3,3]

static func texture_for_frame(frame: int, trial: bool) -> Texture2D:
    var index: int = A_PROFILE[clampi(frame,0,A_PROFILE.size()-1)]
    match index:
        0: return STAND
        1: return SETTLE
        2: return TRIAL_COMPRESSION if trial else BASE_COMPRESSION
        _: return CROUCH

static func apply_to(sprite: Sprite2D, frame: int, trial: bool, facing_left: bool = false) -> void:
    var selected: Texture2D = texture_for_frame(frame,trial)
    sprite.texture = selected
    sprite.centered = true
    sprite.region_enabled = false
    sprite.offset = Vector2(0.0,-float(selected.get_height())*0.5)
    sprite.scale = Vector2.ONE
    sprite.flip_h = facing_left
    sprite.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST

class_name SKS23VisualDriver
extends Node
## Visual-only Profile A transition. Collision/movement truth remains SKCrouchAdapter.
## Attach as a child of the actor; no input handling or collision writes.
const PROFILE = preload("res://scripts/sk_s22_profile.gd")
@export var adapter: SKCrouchAdapter
@export var source_sprite: SKPoseVisual
var overlay: Sprite2D
var phase: int = 0
var last_crouched: bool = false
var frame_tick: int = 0
var active: bool = false
var animation_variant: int = 1

func _ready() -> void:
    if adapter == null or source_sprite == null:
        push_error("S23 animation driver requires adapter and sprite")
        set_physics_process(false)
        return
    overlay = Sprite2D.new()
    overlay.name = "S23ArtOverlay"
    overlay.z_index = source_sprite.z_index + 1
    source_sprite.get_parent().add_child(overlay)
    overlay.position = source_sprite.position
    # Source sprite remains active for authoritative pose verification; only the
    # overlay is rendered. Do not alter its texture or the physics collider.
    source_sprite.modulate.a = 0.0
    last_crouched = adapter.crouched
    phase = 7 if last_crouched else 0
    _render_frame()

func _physics_process(_delta: float) -> void:
    var now_crouched: bool = adapter.crouched
    if now_crouched != last_crouched:
        last_crouched = now_crouched
        active = true
        frame_tick = 0
        phase = 0 if now_crouched else 7
    elif active:
        frame_tick += 1
        phase = mini(frame_tick, 7) if now_crouched else maxi(7 - frame_tick, 0)
        if frame_tick >= 7:
            active = false
    # Stand-blocked requests leave crouched=true; do not start stand animation.
    _render_frame()

func _render_frame() -> void:
    if overlay == null:
        return
    overlay.position = source_sprite.position
    PROFILE.assign(overlay, phase, animation_variant, source_sprite.flip_h)

func is_visual_valid() -> bool:
    return overlay != null and overlay.texture == PROFILE.select(phase, animation_variant) \
        and overlay.offset == Vector2(0, -float(overlay.texture.get_height()) * 0.5) \
        and overlay.scale == Vector2.ONE and overlay.flip_h == source_sprite.flip_h \
        and source_sprite.pose_texture_verified()

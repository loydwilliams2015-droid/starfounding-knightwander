# SK SCALE/ART QA-005 — S16 gameplay-scale review (append-only)

References: **Mega Man X4** (decisive key-pose readability) prioritized; **Dead Cells** (selective motion continuity and production efficiency) secondary. Yoshi / Kirby / Tales of Phantasia remain bracketed from active review. Original game art is never copied.

## Controlled camera study

A/B variables: camera zoom = 0.75, 1.00, 1.50, 2.00; pose = standing/crouching; source sprite and controller unchanged. These zoom values are **experimental**, not approved default camera settings. This is an in-engine 960×540 QA scene using real crouch input but reset/spawn positions are scripted.

**Pass technical gates:** correct authored texture for each state; source sprite scale remains (1,1); character feet retain bottom-center anchor; collider geometry remains unchanged by camera zoom; image size 960×540; 8 distinct native engine renders; test suite passes.

**Human review still required:** face and arm legibility; standing/crouch immediate distinction at default 1x; costume silhouette against bright and dark backgrounds; fine-pixel shimmer at fractional zoom during actual scroll; character vs HUD scale; minimum useful telegraph duration. Do not claim 1.5x is pixel-perfect: noninteger display scaling can have uneven pixels. Compare integer 1x/2x first.

**Industry reference caveats:** Godot documents integer stretch scaling and artifacts introduced by fractional scaling (Multiple Resolutions); Sprite2D texture filtering belongs to CanvasItem; Dead Cells's 3D-to-pixel-art production pipeline emphasizes cost/quality, not a requirement that SK use 3D. All numerical gates above are SK-specific proposals.

**Release boundary:** source QA pass is not production-art certification, nor integration into the original playable SK project.

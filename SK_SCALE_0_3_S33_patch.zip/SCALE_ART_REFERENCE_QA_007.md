# SCALE/ART QA-007 — S18 pixel-phase and contrast acceptance (append-only)

## Reference hierarchy
1. Mega Man X4 — dominant influence: deliberate, readable authored key poses. This is a design analogy, not a source of imported assets or a specification of exact historical frame timings.
2. Dead Cells — secondary influence: efficient art production and selective fluid continuity. Source: Motion Twin artist production deep dive (Game Developer, 2018), https://www.gamedeveloper.com/production/art-design-deep-dive-using-a-3d-pipeline-for-2d-animation-in-i-dead-cells-i-
3. Godot documentation — practical texture filtering, viewport stretch, integer versus fractional scaling. https://docs.godotengine.org/en/stable/tutorials/rendering/multiple_resolutions.html

## S18 controlled experiment
The actor, actual crouch texture, foot anchor and collision geometry are fixed. Camera-only horizontal translation is sampled at +0.00, +0.25, +0.50 and +0.75 world pixels, at 1.0x, 1.5x and 2.0x. Two flat background treatments establish silhouette visibility without the confound of changing scenery. Images are true 960x540 Godot 4.7.2 renderer captures.

Pass requirements (automated): complete 24 images of 960x540; same crouching source resource in every sample; 1:1 sprite transform; stable collider; consistent expected render output for equivalent capture settings; no new animation/controller subsystem.

Human acceptance, not automatically graded: at intended gameplay scale, the crouching silhouette must be legible against both backgrounds and survive purposeful motion without distracting pixel shimmer. Additional work should use actual SK environments and the approved production knight art. Numeric image differences alone cannot establish visual quality.

## Findings
S18 controlled pixel-phase delta is nonzero at some phase steps. These jumps follow raster quantization and do not demonstrate a defect by themselves. Mean frame-difference fraction per zoom is not normalized by silhouette size and therefore must NOT be interpreted as a ranked shimmer score. Never assert that 1.5x has more or less perceived shimmer solely from these measurements.

## Production boundary
The test scene uses original reference sprites. It is not the original SK playable project, and does not certify approved art, final animation, gameplay integration or performance under real game loads.

# SCALE/ART-QA-001 — S12 append-only comparative reference study

This is an **experimental production rubric**, not a claim that Mega Man X4 or Dead Cells publishes these exact metrics. Yoshi / Kirby / Tales of Phantasia remain explicitly bracketed.

## Reference-derived principles
- **Mega Man X4:** discrete, authored action poses and distinct silhouettes; emphasize perceptual clarity at gameplay zoom. The 1997 developer interview reports a large sprite-animation workload, so animation budgets must be deliberate.
- **Dead Cells:** reusable character/animation pipeline rather than frame-for-frame hand-cleanup at every iteration; the documented 3D-to-low-resolution conversion is an optional future method, **not** a mandate to switch SK to 3D.
- **Godot:** maintain explicit Sprite2D origin, nearest sampling for source pixel geometry, and test camera/viewport scaling. Pixel-art effects and high-res lighting may use separate rendering policies.

## Proposed pass/fail criteria (project thresholds)
1. **Hard PASS** when the actual pose texture is assigned and no stretch/negative sprite scale occurs; a different crouch sprite is mandatory.
2. **Hard PASS** when collider and image are simultaneously foot anchored and crouch-to-stand clearance obeys physics.
3. **Hard PASS** when 30 repeated pose round-trips preserve geometry and texture integrity.
4. **Review** silhouette at native 960×540 viewport on dark, mid and light value backgrounds, and in six-character visual density.
5. **Review** contrast and limb/equipment legibility by a human at normal presentation size. Proposed practical scoring: 4/5 readers identify the action within 1 second; not yet empirically measured.
6. **Review** walking/crouching transitions for character volume, foot sliding and animation beats once approved intermediate frames exist. No fake animation equivalence.
7. **Review** performance on intended target hardware; current software-rendered screenshots do not qualify.

## Restrictions
Do not copy game sprite pixels, create derivative sheets, or overwrite the original SK project. Existing knight source PNGs remain reference-only. Offline contact sheets are not substituted for in-engine screenshots.

## References
- Thomas Vasseur, Game Developer, *Art Design Deep Dive: Using a 3D pipeline for 2D animation in Dead Cells* (2018).
- *Mega Man X4* 1997 developer interview, translation at shmuplations.
- Godot Sprite2D and Multiple resolutions documentation.

# SCALE/ART QA-008 — S19 additive reference-art experiment

**Decision:** Profile A remains incumbent; preserve Mega Man X4-inspired key-pose clarity and use Dead Cells-style transitional polish selectively. The S19 compression image is original experimental SK reference art, not copied source art and not the previously approved sprite.

**Proposed hard gates:** never let visual animation control or change authoritative crouch collision; standing/crouching textures remain separate; preserve original sprite colors and 64px widths; prevent feet from visibly drifting between frames; preserve directional facing without negative scale; require full scene readability at normal gameplay zoom.

**Human acceptance review:** compare the knee bend, two-leg separation, leg/boot grounding, equipment focal point, and costume continuity between settle, compression and crouch. Test at 1x and 2x against dark/medium backgrounds. An increase in contrast is not a substitute for a correct anatomical pose.

**Evidence rule:** runtime Godot captures can verify texture display and alignment; only playtesting against the actual SK environment and original approved art can certify production readiness.

# SK SCALE/ART reference hypotheses — S13 (append-only)

Active comparative influences: **Mega Man X4** (key-pose differentiation, explicit silhouettes) and **Dead Cells** (animation-production efficiency and fluid transition timing). These are interpretive design hypotheses, **not** claims that either commercial game uses these frame intervals.

S13 uses two newly constructed, original SK pixel-art transition sketches: 64×112 `settle`, 64×94 `compress`, aligned on the same foot baseline as 64×128 standing and 64×80 crouching. They are **experimental and not approved replacement art**. Neither is used in the authoritative collider or input controller.

Two 8-sample (12 fps review playback) timing models:

* A / Key-pose emphasis: `[stand, stand, settle, crouch, crouch, crouch, crouch, crouch]`.
* B / Intermediate timing: `[stand, settle, settle, compress, compress, crouch, crouch, crouch]`.

Technical invariants: unscaled PNG textures; bottom-center feet; nearest filtering; collision switches at the authoritative crouch state independently of animation; no animation should delay collision-safe crouch; standing remains clearance gated.

Human-art review gates (open): normal-play silhouette clarity, intermediate-frame visual continuity, foot jitter, motion feel, lighting, accessibility/reduced-motion preference, final approved costume identity. The screenshots show genuine staged Godot rendering, not original-game playtest footage.

# SCALE/ART QA-012 — S23 input-driven pose presentation

**Reference priority:** Mega Man X4-style decisive key poses (Profile A); Dead Cells-style motion continuity is secondary. Original reference art only; no borrowed game assets.

## Acceptance criteria

1. The gameplay controller owns crouch, input and collision; visual transition nodes must never modify shape geometry or player velocity.
2. At 60 Hz the eight-step Profile A art sequence is [standing, standing, settling, compression, crouch, crouch, crouch, crouch]. The reverse visual transition follows authoritative safe stand clearance.
3. If the player attempts standing under a roof, the crouch pose remains visible until the collider can safely expand.
4. Frame-by-frame verification must inspect the **visible overlay texture**, not just the authoritative (hidden) pose sprite texture.
5. The rendered overlay must remain opaque, foot-anchored, 1:1, and horizontally flipped with actual facing. It must not inherit opacity from the hidden authoritative sprite.
6. Gameplay-scale review: 960×540 native viewport, screenshots from engine, and readable pose distinctions at normal 1× zoom. Human visual judgment is still required.
7. Preserve baseline control art, collision system and both S22 variants. No claim of original full-game integration.

## Status
Native source assertions and engine captures pass in standalone QA; original production sprite, human readability acceptance, and full-game integration remain open.

from PIL import Image,ImageDraw,ImageFont
from pathlib import Path
import numpy as np,json,hashlib
P=Path(__file__).resolve().parents[1]; C=P/'captures/s18_engine'
zooms=[100,150,200]; phases=[0,25,50,75]; colors=[(24,37,43),(140,145,144)]
metrics={"study":"S18 fixed actor and sprite; only camera fractional horizontal phase changes","backgrounds":{"dark":"#18252b","mid":"#8c9190"},"zooms":{},"limitations":"Image differences record screen-space raster phase and cannot alone establish perceived flicker or optimum gameplay zoom."}
for b in range(2):
 for z in zooms:
  ims=[];masks=[];boxes=[]
  for phase in phases:
   im=np.asarray(Image.open(C/f'contrast_{b}_zoom_{z:03d}_phase_{phase:02d}.png').convert('RGB'))
   sub=im[100:440,300:660,:].astype(np.int16)
   mask=np.max(np.abs(sub-np.asarray(colors[b])),axis=2)>16
   yy,xx=np.nonzero(mask)
   masks.append(mask);ims.append(sub);boxes.append([int(xx.min()),int(yy.min()),int(xx.max()),int(yy.max())] if len(xx) else None)
  changes=[]
  for j in range(3):
   changes.append({"phase_pair":[phases[j],phases[j+1]],"changed_pixel_fraction":round(float(np.any(ims[j]!=ims[j+1],axis=2).mean()),6),"silhouette_xor_pixels":int(np.logical_xor(masks[j],masks[j+1]).sum())})
  metrics['zooms'][f'background_{b}_zoom_{z}']={"bounding_boxes_relative_to_crop":boxes,"phase_changes":changes,"mean_changed_pixel_fraction":round(float(np.mean([x['changed_pixel_fraction'] for x in changes])),6)}
(C/'s18_fixed_pose_metrics.json').write_text(json.dumps(metrics,indent=2))
# 3 x 2 contact sheet: crop useful image around sprite to focus readability
W,H=500,380
sheet=Image.new('RGB',(W*3,H*2),'#111923'); d=ImageDraw.Draw(sheet)
for b in range(2):
 for j,z in enumerate(zooms):
  im=Image.open(C/f'contrast_{b}_zoom_{z:03d}_phase_00.png').convert('RGB')
  crop=im.crop((230,85,730,445))
  sheet.paste(crop,(j*W,b*H+20))
  d.text((j*W+12,b*H+2),f'{z/100:g}x  |  {"dark" if b==0 else "mid"} backdrop | crouching',fill='white')
sheet.save(C/'s18_contrast_contact_sheet.png')
# gif with 3 zooms each phase dark first then mid (24 frames) scaled to 480x270
frames=[]
for b in range(2):
 for z in zooms:
  for p in phases:
   f=Image.open(C/f'contrast_{b}_zoom_{z:03d}_phase_{p:02d}.png').convert('RGB').resize((480,270),Image.Resampling.NEAREST)
   dr=ImageDraw.Draw(f);dr.rectangle((0,0,310,24),fill='#18252b');dr.text((8,6),f'S18 {"DARK" if b==0 else "MID"} | zoom {z}% | phase {p/100:.2f}px',fill='white')
   frames.append(f)
frames[0].save(C/'s18_pixel_phase_review.gif',save_all=True,append_images=frames[1:],duration=240,loop=0,optimize=False)
print(json.dumps({k:{'avg':v['mean_changed_pixel_fraction'],'xor':[c['silhouette_xor_pixels'] for c in v['phase_changes']]} for k,v in metrics['zooms'].items()},indent=2))

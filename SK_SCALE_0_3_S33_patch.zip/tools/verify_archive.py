#!/usr/bin/env python3
"""Verify the exact SK SCALE/ART S30 handoff zip and expected project layout.

Proves only archive integrity and basic project inventory, not gameplay validity.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import zipfile
from pathlib import Path

EXPECTED_SHA256 = "8607d10dd6238e88364874a1eead4571f4b86c5acd1a75f9a02f320f4ff6d53c"
EXPECTED = (
    "project.godot",
    "scripts/sk_s25_stage.gd",
    "scripts/sk_crouch_adapter.gd",
    "scripts/sk_s23_visual_driver.gd",
    "scenes/sk_s25_visual_reintegration.tscn",
    "assets/knight_standing.png",
    "assets/knight_crouching.png",
    "tests/s30_vertical_camera_test.gd",
    "S30_VERIFICATION.json",
)


def verify(path: Path, check_canonical: bool = True) -> dict:
    digest = hashlib.sha256(path.read_bytes()).hexdigest()
    with zipfile.ZipFile(path) as z:
        bad_member = z.testzip()
        names = z.namelist()
        missing = [name for name in EXPECTED if not any(n == name or n.endswith('/' + name) for n in names)]
    good = bad_member is None and not missing and (not check_canonical or digest == EXPECTED_SHA256)
    return {
        "archive": str(path), "sha256": digest,
        "canonical_s30_match": digest == EXPECTED_SHA256,
        "crc_ok": bad_member is None,
        "missing_expected_paths": missing,
        "member_count": len(names), "pass": good,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("archive", type=Path)
    parser.add_argument("--allow-noncanonical", action="store_true")
    args = parser.parse_args()
    result = verify(args.archive, not args.allow_noncanonical)
    print(json.dumps(result, indent=2))
    return 0 if result["pass"] else 1


if __name__ == "__main__":
    raise SystemExit(main())

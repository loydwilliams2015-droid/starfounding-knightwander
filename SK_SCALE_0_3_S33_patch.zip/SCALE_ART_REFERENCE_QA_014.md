# SK SCALE/ART QA-014 — S26 reversible scene-readability grade

Profile A remains authoritative for presentation timing. The S26 environment grade *only* adjusts midground foliage, architecture, foreground alpha and lamp energy. It must not alter pose PNGs, animation schedules, collider dimensions, camera zoom, parallax scroll rates or physics behavior.

Review against Mega Man X4-style decisive silhouettes and Dead Cells-style atmospheric visual hierarchy without copying either game's assets. Inspect native 960×540 screenshots at gameplay scale and compare the *same* actor pose at identical world positions. Human art approval remains open. The new readability mode is experimental, not the default game setting.

Pass gates: correct dedicated crouch sprite in both modes, reproducible environment toggling, exact parallax-rate invariance, collision geometry and foot anchoring, capture integrity, and no regression in inherited S25 QA. Visual clarity remains a human judgment.

# S30 GitHub handoff

**Not published.** Connected account exposes `loydwilliams2015-droid/nightfall_punk` and `loydwilliams2015-droid/mechanical-dream`, but no verifiable Starfounding Knightwander repository. Neither has been modified.

Create or identify the intended SK GitHub repository; then import this standalone QA project to a dedicated `qa/scale-art/` directory or a new repository, retaining its test-only designation. Do not overwrite production project files or its existing animation controller.

Suggested branch: `feat/sk-scale-art-s30-vertical-camera`. Suggested commit: `feat(sk-scale-art): add bounded jump look-ahead and native regression captures`.

Source scope: `scripts/`, `scenes/`, `tests/`, `assets/`, `project.godot`, `SCALE_ART_REFERENCE_QA_018.md`, and `README.md`. Exclude `.godot/`, `*.import`, screenshots unless intentionally storing QA evidence, Godot binary, and temporary logs.

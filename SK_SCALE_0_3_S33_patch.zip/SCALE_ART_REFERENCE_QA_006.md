# SCALE/ART QA-006 — S17 Scrolling Camera Amendment (append-only)

**Reference direction:** Mega Man X4 (deliberate key-pose clarity) primary; Dead Cells (selective movement continuity and lighting) secondary. Profile A remains incumbent.

**Objective:** Evaluate viewport-stable crouching silhouettes during camera translation at 1× / 1.5× / 2× and under a world-space 32-pixel-grid background.

**Mandatory gates:** use actual `sk_crouch` and `sk_right` actions; keep dedicated crouch texture, 1:1 Sprite2D scale, foot-centered origin, and authoritative collision; capture the same camera-follow trajectory at each zoom.

**Review-only metric:** adjacent-frame pixel change measured within a character-centered crop, plus stability against grid. Changes reflect actual world/camera movement and cannot alone diagnose shimmer. Fractional zoom is exploratory, not a proposed gameplay default.

**Scope:** standalone QA, reference sprites only. Do not claim original SK production integration, final art grading or player-recorded gameplay. Do not import protected game sprite assets.

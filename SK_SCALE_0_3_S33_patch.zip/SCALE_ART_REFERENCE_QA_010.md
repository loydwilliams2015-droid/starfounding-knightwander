# SCALE/ART QA-010 — S21 settling-to-compression continuity

Append-only amendment following QA-001 through QA-009. The selected art direction remains Profile A (Mega Man X4-style intentional key poses), with restrained Dead Cells-informed fluidity.

- S20 compression sprite retained intact; new S21 settle variation is reversible and reference-only.
- Keyframe order unchanged: stand, settle, compress, crouch. Do not interpolate the authoritative collision shape from visual keys.
- For each frame verify source identity, 1:1 sprite transform, shared foot origin and facing. Check silhouette width and upper/lower centroid with `s21_trajectory_metrics.json`.
- Evaluate at native 960×540 on a representative **original** procedural stone/foliage environment, not a borrowed game screenshot.
- Observe hip/knee line, boots, belt and arm/weapon continuity by eye: raw alpha centroids cannot demonstrate anatomy or smoothness.
- Candidate promotion requires human art approval and integration into the real SK project. This standalone scene is not that integration.

References: Godot Sprite2D API https://docs.godotengine.org/en/stable/classes/class_sprite2d.html; Game Developer Dead Cells production pipeline https://www.gamedeveloper.com/production/art-design-deep-dive-using-a-3d-pipeline-for-2d-animation-in-i-dead-cells-i-

# SK SCALE/ART S32 — Camera ownership and recoverability

Built on the S31 standalone Godot QA project, not the full production game.

Changes: reversible explicit camera ownership between S27 manual pixel-phase review and S29/S30 automatic horizontal/vertical look-ahead. Adds `tests/s32_camera_ownership_test.gd`, with six manual→automatic cycles, player-input crouch reversals and parallax integrity assertions.

Godot 4.7.2 workflow:

```
godot --headless --editor --path . --quit
godot --headless --path . --script res://tests/s32_camera_ownership_test.gd
```

`qa/scale-art` remains the intended isolated test home if imported into the original Starfounding Knightwander repository. Never overwrite the original game blindly. Reference sprites are not final production artwork.

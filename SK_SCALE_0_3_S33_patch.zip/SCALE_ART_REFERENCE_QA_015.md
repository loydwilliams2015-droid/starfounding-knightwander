# QA-015 — Continuous parallax and platform separation (append-only)

S27 keeps S26 art and Profile A untouched. Test camera offset at fractional and snapped world-pixel positions; compare 1× captures without rescaling actor texture. Layers must retain strict depth ordering, the lower-body collision contract must pass, and decorative foreground must never imply a solid platform. Screen pixel deltas are diagnostic, NOT equivalent to perceived shimmer or measured performance. Production art and main-game integration remain open.

**References:** Mega Man X4 — strong silhouette/readable platforms; Dead Cells — atmospheric layering with character prioritization. Original SK geometry only.

# SCALE/ART QA-013 (append-only): animation transport fidelity

**Accepted technical mapping:** source pose PNG -> eight-tick Profile A index sequence -> Godot Sprite2D texture -> full-scene viewport capture -> GIF assembly. Each stage retains distinct dimensions/timing.

**Pass:** source hashes match manifest; atlas matches source pixels exactly; bottom alignment preserved; native profile index and texture mapping match atlas; the GIF is clearly labeled with review frame duration.

**Not proved by GIF:** 60Hz playback timing, interactive input responsiveness, exact camera motion and approved visual aesthetics. Short delays may be clamped or quantized; GIF has limited color representation.

Primary stylistic reference: Mega Man X4 deliberate key poses. Secondary: Dead Cells fluidity if it does not obscure collision state. Yoshi/Kirby/ToP remain bracketed out.

**GIF coalescing observation:** 8 animation ticks are encoded as four unique GIF images; repeated standing/crouching holds are represented by longer frame durations.

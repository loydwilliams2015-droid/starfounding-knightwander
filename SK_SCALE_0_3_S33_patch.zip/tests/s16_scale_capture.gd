extends SceneTree
## Engine-rendered camera zoom review. Real input actions drive the QA actor.
## Visual results are from the standalone QA scene, not the original game.
const SCENE = preload("res://scenes/sk_pose_demo.tscn")
const ZOOMS = [0.75, 1.0, 1.5, 2.0]
var captures: int = 0
func _initialize() -> void: call_deferred("run")
func frames(n: int) -> void:
    for i in n: await physics_frame
func run() -> void:
    root.content_scale_size = Vector2i(960, 540)
    var demo := SCENE.instantiate()
    root.add_child(demo)
    current_scene = demo
    await frames(5)
    var actor: CharacterBody2D = demo.actor
    var pose: SKCrouchAdapter = demo.adapter
    var camera := Camera2D.new()
    camera.name = "S16QACamera"
    camera.position_smoothing_enabled = false
    demo.add_child(camera)
    camera.make_current()
    # Reviewer-readable overlay: CanvasLayer ignores the Camera2D zoom.
    var review_label := Label.new()
    review_label.add_theme_font_size_override("font_size", 17)
    review_label.position = Vector2(20, 125)
    demo.hud.get_parent().add_child(review_label)
    DirAccess.make_dir_recursive_absolute(ProjectSettings.globalize_path("res://captures/s16_engine"))
    for zi in ZOOMS.size():
        var zoom_value: float = ZOOMS[zi]
        for crouch_id in range(2):
            # Use the actual control path to select the rendered texture.
            actor.global_position = Vector2(240, 450)
            actor.velocity = Vector2.ZERO
            if crouch_id == 1: Input.action_press("sk_crouch")
            else: Input.action_release("sk_crouch")
            await frames(5)
            camera.position = actor.global_position + Vector2(0, -52)
            camera.zoom = Vector2.ONE * zoom_value
            review_label.text = "S16 CAMERA STUDY | zoom %.2fx | %s | %s" % [zoom_value, "CROUCH" if crouch_id == 1 else "STAND", "REFERENCE ART"]
            if not pose.visual.pose_texture_verified():
                push_error("Pose visual mismatch at zoom %.2f" % zoom_value)
                quit(1)
                return
            for j in range(3): await process_frame
            await RenderingServer.frame_post_draw
            var im := root.get_viewport().get_texture().get_image()
            var outfile := "res://captures/s16_engine/zoom_%03d_%s.png" % [roundi(zoom_value * 100), "crouch" if crouch_id == 1 else "stand"]
            if im.get_width() != 960 or im.get_height() != 540 or im.save_png(outfile) != OK:
                push_error("Screenshot creation failed: " + outfile)
                quit(1)
                return
            captures += 1
    Input.action_release("sk_crouch")
    print("S16_SCALE_CAPTURE PASS %d frames" % captures)
    quit(0)

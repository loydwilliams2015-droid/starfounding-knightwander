#!/usr/bin/env python3
"""S8 source and asset acceptance. This is NOT a native Godot physics test."""
from pathlib import Path
from PIL import Image
import json, hashlib, sys
R = Path(__file__).resolve().parents[1]
contract=json.loads((R/'art_contract.json').read_text())
checks=[]
def check(ok,label):
    checks.append((label, bool(ok)))
    if not ok: print('FAIL',label)
check(contract['release']=='S8','release')
check(contract['approved_sprite_recovered'] is False,'not falsely certified')
for name,asset in contract['assets'].items():
    p=R/asset['relative_path']; image=Image.open(p).convert('RGBA')
    check(list(image.size)==asset['dimensions_px'],name+' dimensions')
    check(list(image.getchannel('A').getbbox())==asset['alpha_bbox_xyxy'],name+' alpha bounds')
    check(hashlib.sha256(p.read_bytes()).hexdigest()==asset['sha256'],name+' unmodified PNG')
    check(asset['role']=='REFERENCE_ONLY_NOT_APPROVED_PRODUCTION_ART',name+' provenance')
v=(R/'scripts/sk_pose_visual.gd').read_text()
a=(R/'scripts/sk_crouch_adapter.gd').read_text()
t=(R/'tests/pose_runtime_test.gd').read_text()
check('texture == (crouching_texture if value else standing_texture)' in v,'same-pose texture identity check')
check('func repair_pose_texture() -> bool:' in v,'texture repair function')
check('visual.repair_pose_texture()' in a,'adapter invokes texture repair')
check('same-state crouch repairs stale standing sprite' in t,'native regression authored')
check('squashed sprite detected' in t,'scale mutation regression authored')
check('query.exclude = [body.get_rid()]' in a,'headroom self-exclusion')
check('scale = Vector2.ONE' in v and 'flip_h = value' in v,'scale and facing contract')
check(Image.open(R/'previews/s8_asset_pose_contact_sheet.png').size==(960,540),'reference review size')
check((R/'tests/capture_pose_frames.gd').read_text().find('s8_runtime_captures')>=0,'Godot capture script')
result={'release':'S8','static_checks':len(checks),'passed':sum(v for _,v in checks),'failed':[k for k,v in checks if not v],'godot_runtime':'NOT RUN','original_game_integration':'NOT RUN','production_art':'REFERENCE ONLY'}
(R/'tests/s8_static_results.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
sys.exit(0 if all(v for _,v in checks) else 1)

extends SceneTree
## Validate real input under multiple zoom levels without modifying the actor's sprite scale.
const SCENE = preload("res://scenes/sk_pose_demo.tscn")
const ZOOMS = [0.75, 1.0, 1.5, 2.0]
var count := 0
var failures := 0
func _initialize() -> void: call_deferred("run")
func check(ok: bool, why: String) -> void:
    count += 1
    if not ok:
        failures += 1
        push_error("S16 FAIL: " + why)
func frames(n: int) -> void:
    for i in n: await physics_frame
func run() -> void:
    var demo := SCENE.instantiate()
    root.add_child(demo)
    current_scene=demo
    var camera := Camera2D.new()
    demo.add_child(camera)
    camera.make_current()
    await frames(5)
    var actor: CharacterBody2D=demo.actor
    var pose: SKCrouchAdapter=demo.adapter
    for z in ZOOMS:
        camera.zoom=Vector2(z,z)
        for want_crouch in [false,true]:
            actor.global_position=Vector2(240,450)
            actor.velocity=Vector2.ZERO
            if want_crouch: Input.action_press("sk_crouch")
            else: Input.action_release("sk_crouch")
            await frames(5)
            check(pose.crouched == want_crouch, "actual input selects pose at zoom %s" % z)
            check(pose.visual.pose_texture_verified(), "verified correct renderer texture at zoom %s" % z)
            check(pose.pose_geometry_verified(), "geometry remains authoritative at zoom %s" % z)
            check(pose.visual.scale==Vector2.ONE, "camera zoom never mutates sprite scale at zoom %s" % z)
            check(pose.visual.offset.is_equal_approx(Vector2(0,-float(pose.visual.texture.get_height())/2)), "feet stable at zoom %s" % z)
            check(camera.zoom.is_equal_approx(Vector2(z,z)), "camera has requested zoom %s" % z)
    Input.action_release("sk_crouch")
    print("S16_SCALE_TEST %s %d/%d" % ["PASS" if failures==0 else "FAIL",count-failures,count])
    quit(0 if failures==0 else 1)

extends SceneTree
## Godot native smoke/physics regression: godot --headless --path . --script res://tests/pose_runtime_test.gd
const SCENE = preload("res://scenes/sk_pose_demo.tscn")
var failures: Array[String] = []

func _initialize() -> void:
    call_deferred("_run")

func check(condition: bool, message: String) -> void:
    if condition:
        print("PASS ", message)
    else:
        push_error("FAIL " + message)
        failures.append(message)

func _run() -> void:
    var demo := SCENE.instantiate()
    root.add_child(demo)
    current_scene = demo
    # Isolate pose/physics assertions from demo input-driven _physics_process.
    # Without this, releasing Ctrl every frame can undo each test crouch.
    demo.set_physics_process(false)
    await physics_frame
    await physics_frame
    var body: CharacterBody2D = demo.actor
    var pose: SKCrouchAdapter = demo.adapter
    var art: SKPoseVisual = pose.visual
    check(not pose.crouched and art.texture == art.standing_texture, "standing selects standing art")
    check(is_equal_approx(pose.collider.position.y, -60.0), "standing collider feet aligned")
    check(pose.request_crouch(true), "crouch accepted")
    check(pose.crouched and art.texture == art.crouching_texture, "crouch selects dedicated art")
    check(is_equal_approx(pose.collider.position.y, -33.6), "crouching collider feet aligned")
    check(art.scale == Vector2.ONE, "no texture squash")
    art.set_facing_left(true)
    check(art.flip_h and art.scale == Vector2.ONE, "left facing mirrors via flip_h only")
    check(art.texture == art.crouching_texture, "turning does not replace crouch art")
    art.set_facing_left(false)
    check(not art.flip_h, "right facing resets flip_h")
    check(art.current_asset_path() == "res://assets/knight_crouching.png", "runtime crouch resource path")
    # Regression: another system swaps texture while pose flag stays crouched.
    art.texture = art.standing_texture
    check(not art.pose_texture_verified(), "incorrect external texture detected")
    check(pose.request_crouch(true), "same-state crouch request succeeds")
    check(art.texture == art.crouching_texture and art.pose_texture_verified(), "same-state crouch repairs stale standing sprite")
    # Rendering settings can also be mutated by external animation tracks.
    art.scale = Vector2(1.0, 0.75)
    check(not art.pose_texture_verified(), "squashed sprite detected")
    check(art.repair_pose_texture() and art.scale == Vector2.ONE, "distorted sprite repaired")
    # Under the roof [510..930] and floor top y=450; head clearance is 70px.
    body.global_position = Vector2(650, 450)
    body.velocity = Vector2.ZERO
    await physics_frame
    check(not pose.request_crouch(false), "stand blocked beneath roof")
    check(pose.crouched and pose.stand_blocked, "blocked stand preserves crouch")
    # Outside roof: standing should be allowed while touching the floor.
    body.global_position = Vector2(240, 450)
    body.velocity = Vector2.ZERO
    await physics_frame
    check(pose.request_crouch(false), "stand allowed outside roof on ground")
    check(not pose.crouched and art.texture == art.standing_texture, "standing art restored")
    check(not pose.stand_blocked, "blocked indicator clears")
    check(art.current_asset_path() == "res://assets/knight_standing.png", "runtime stand resource path")
    # Pose selection must report the assigned render texture, not inferred state.
    check(art.current_asset_path() == art.texture.resource_path, "HUD names actual selected render resource")
    # Move under the ceiling while crouched and remain crouched when blocked.
    pose.request_crouch(true)
    body.global_position = Vector2(520, 450)
    body.velocity = Vector2.ZERO
    await physics_frame
    check(not pose.request_crouch(false) and pose.crouched, "roof edge blocks premature stand")
    body.global_position = Vector2(470, 450)
    body.velocity = Vector2.ZERO
    await physics_frame
    check(pose.request_crouch(false), "stand recovers after moving out from under roof")
    check(art.texture == art.standing_texture and art.scale == Vector2.ONE, "recovery restores standing art 1:1")
    # A blocked stand request must not change the authored crouch texture.
    pose.request_crouch(true)
    body.global_position = Vector2(650, 450)
    await physics_frame
    check(not pose.request_crouch(false), "blocked stand request returns false")
    check(art.texture == art.crouching_texture, "blocked stand retains crouching source image")
    body.global_position = Vector2(240, 450)
    await physics_frame
    check(pose.request_crouch(false), "standing restored after clearing headroom")
    # Rapid repeated requests should be idempotent.
    for i in range(20):
        check(pose.request_crouch(true), "crouch repeat %02d" % i)
    check(art.texture == art.crouching_texture and art.scale == Vector2.ONE, "repeated crouch keeps authored pixels")
    print("S8_RESULT: ", "PASS" if failures.is_empty() else "FAIL (%d)" % failures.size())
    quit(0 if failures.is_empty() else 1)

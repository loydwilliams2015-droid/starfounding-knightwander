extends SceneTree
## Tests camera movement and pose invariants on a moving 2D gameplay actor.
const SCENE = preload("res://scenes/sk_pose_demo.tscn")
const ZOOMS = [1.0, 1.5, 2.0]
var checks := 0
var failures := 0
func check(ok: bool, reason: String) -> void:
    checks += 1
    if not ok:
        failures += 1
        push_error("S17 FAIL " + reason)
func frames(n: int) -> void:
    for i in n: await physics_frame
func _initialize() -> void: call_deferred("run")
func run() -> void:
    var demo = SCENE.instantiate()
    root.add_child(demo)
    current_scene = demo
    await frames(5)
    var camera := Camera2D.new()
    demo.add_child(camera)
    camera.position_smoothing_enabled = false
    camera.make_current()
    var actor: CharacterBody2D = demo.actor
    var pose: SKCrouchAdapter = demo.adapter
    for z in ZOOMS:
        camera.zoom = Vector2(z,z)
        actor.global_position = Vector2(165,450)
        actor.velocity = Vector2.ZERO
        Input.action_press("sk_crouch")
        Input.action_press("sk_right")
        await frames(4)
        var initial_x: float = actor.global_position.x
        for step in 8:
            await frames(2)
            camera.global_position = actor.global_position + Vector2(0,-52)
            check(actor.global_position.x > initial_x, "actor advances at %.2fx step %d" % [z,step])
            check(pose.crouched, "crouch input persists at %.2fx step %d" % [z,step])
            check(pose.visual.pose_texture_verified(), "texture/anchor verified at %.2fx step %d" % [z,step])
            check(pose.pose_geometry_verified(), "collider valid at %.2fx step %d" % [z,step])
            check(pose.visual.scale == Vector2.ONE, "sprite remains 1:1 at %.2fx step %d" % [z,step])
            initial_x = actor.global_position.x
        Input.action_release("sk_right")
        Input.action_release("sk_crouch")
        await frames(4)
    check(not pose.crouched, "standing recovered")
    print("S17_MOTION_TEST %s %d/%d" % ["PASS" if failures==0 else "FAIL",checks-failures,checks])
    quit(0 if failures==0 else 1)

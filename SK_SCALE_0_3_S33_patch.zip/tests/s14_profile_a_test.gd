extends SceneTree
## S14: Profile A timing contract, art provenance, stable bottom-center pivot.
const TEX = [preload("res://assets/knight_standing.png"), preload("res://assets/knight_transition_settle.png"), preload("res://assets/knight_transition_compress.png"), preload("res://assets/knight_crouching.png")]
const A13 = [0, 0, 1, 3, 3, 3, 3, 3]
const A14 = [0, 0, 1, 2, 3, 3, 3, 3]
const B13 = [0, 1, 1, 2, 2, 3, 3, 3]
var checked := 0
var failed := 0
func _initialize() -> void: call_deferred("run")
func check(condition: bool, detail: String) -> void:
    checked += 1
    if not condition:
        failed += 1
        push_error("S14 FAIL "+detail)
func run() -> void:
    check(A14.size() == 8, "8 frames")
    check(A14 != A13, "changes earlier A")
    check(A14 != B13, "not B")
    check(A14[0] == 0 and A14[7] == 3, "endpoints")
    check(A14.count(2) == 1, "single compression emphasis")
    for i in range(A14.size()):
        var j: int = A14[i]
        check(j >= 0 and j < TEX.size(), "valid phase %d"%i)
        check(i == 0 or A14[i-1] <= j, "monotonic %d"%i)
        check(TEX[j].get_width() == 64, "consistent width %d"%i)
        check(TEX[j].get_image().get_used_rect().has_area(), "opaque pose %d"%i)
        var sprite := Sprite2D.new()
        sprite.texture = TEX[j]
        sprite.centered = true
        sprite.offset = Vector2(0.0, -float(sprite.texture.get_height()) / 2.0)
        sprite.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
        check(absf(sprite.offset.y + float(TEX[j].get_height())/2.0) < 0.01, "fixed foot anchor %d"%i)
        check(sprite.scale == Vector2.ONE, "native 1:1 %d"%i)
        sprite.free()
    print("S14_PROFILE_RESULT ", "PASS" if failed == 0 else "FAIL", " ",checked," checks")
    quit(0 if failed == 0 else 1)

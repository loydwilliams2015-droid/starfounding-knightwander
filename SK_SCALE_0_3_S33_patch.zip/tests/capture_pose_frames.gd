extends SceneTree
## S9: deterministic engine-rendered acceptance frames with scene metadata.
## Run with a rendering display (e.g. xvfb-run); these ARE engine frames,
## although positions/poses are staged, not recorded player input.
const SCENE = preload("res://scenes/sk_pose_demo.tscn")
var failures: Array[String] = []

func _initialize() -> void:
    call_deferred("_capture")

func _save_frame(scene: Node2D, path: String, label: String, expected_crouch: bool, expected_blocked: bool) -> void:
    var adapter: SKCrouchAdapter = scene.adapter
    var sprite: SKPoseVisual = adapter.visual
    scene.hud.text = "SK SCALE/ART S9 | GODOT 4.7.2 ENGINE CAPTURE\n%s\nPose: %s | Stand blocked: %s\nAssigned texture: %s\nReference sprite only; approved production sprite pending" % [label, "CROUCH" if adapter.crouched else "STAND", str(adapter.stand_blocked), sprite.current_asset_path()]
    if adapter.crouched != expected_crouch or adapter.stand_blocked != expected_blocked or not sprite.pose_texture_verified():
        failures.append("pose contract mismatch: " + label)
    await process_frame
    await process_frame
    await RenderingServer.frame_post_draw
    var image: Image = scene.get_viewport().get_texture().get_image()
    if image == null or image.is_empty() or image.get_width() != 960 or image.get_height() != 540:
        failures.append("image capture invalid: " + label)
        return
    var err := image.save_png(path)
    if err != OK:
        failures.append("save failed: " + label)
    else:
        print("CAPTURED: ", path)

func _capture() -> void:
    var scene := SCENE.instantiate()
    root.add_child(scene)
    current_scene = scene
    scene.set_physics_process(false) # Controlled QA staging, never claimed to be user-played gameplay.
    await physics_frame
    var adapter: SKCrouchAdapter = scene.adapter
    var body: CharacterBody2D = scene.actor
    var folder := "res://captures/s9_engine"
    DirAccess.make_dir_recursive_absolute(ProjectSettings.globalize_path(folder))
    body.global_position = Vector2(240, 450)
    adapter.request_crouch(false)
    await physics_frame
    await _save_frame(scene, folder + "/01_stand.png", "Standing / open air", false, false)
    adapter.request_crouch(true)
    await physics_frame
    await _save_frame(scene, folder + "/02_crouch.png", "Crouching / open air", true, false)
    body.global_position = Vector2(650, 450)
    await physics_frame
    if adapter.request_crouch(false):
        failures.append("unexpected standing under roof")
    await _save_frame(scene, folder + "/03_blocked.png", "Crouched / standing blocked by ceiling", true, true)
    body.global_position = Vector2(240, 450)
    await physics_frame
    if not adapter.request_crouch(false):
        failures.append("stand recovery failed")
    await _save_frame(scene, folder + "/04_recovered.png", "Standing / headroom restored", false, false)
    print("S9_CAPTURE_RESULT: ", "PASS" if failures.is_empty() else "FAIL " + str(failures))
    quit(0 if failures.is_empty() else 1)

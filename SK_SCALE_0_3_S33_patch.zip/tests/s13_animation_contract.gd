extends SceneTree
const A = preload("res://assets/knight_transition_settle.png")
const B = preload("res://assets/knight_transition_compress.png")
const C = preload("res://assets/knight_crouching.png")
const S = preload("res://assets/knight_standing.png")
var checked := 0
var failed := 0
func _initialize() -> void: call_deferred("run")
func verify(ok: bool, description: String) -> void:
    checked+=1
    if not ok:
        failed+=1
        push_error("S13 FAIL: "+description)
func run() -> void:
    verify(S.get_size()==Vector2(64,128),"standing dimensions")
    verify(A.get_size()==Vector2(64,112),"settle dimensions")
    verify(B.get_size()==Vector2(64,94),"compress dimensions")
    verify(C.get_size()==Vector2(64,80),"crouch dimensions")
    for t in [S,A,B,C]:
        verify(t != null,"resource loaded")
        verify(t.get_image().get_used_rect().has_area(),"nonempty pixels")
        verify(t.get_width()==64,"fixed asset width")
    var hard: Array[int]=[0,0,1,3,3,3,3,3]
    var fluid: Array[int]=[0,1,1,2,2,3,3,3]
    for i in range(8):
        verify(hard[i]>=0 and hard[i]<4,"hard frame index")
        verify(fluid[i]>=0 and fluid[i]<4,"fluid frame index")
        verify(hard[i]<=hard[min(i+1,7)],"hard monotonic progression")
        verify(fluid[i]<=fluid[min(i+1,7)],"fluid monotonic progression")
    verify(hard[7]==3 and fluid[7]==3,"both end crouched")
    verify(hard!=fluid,"distinct timing")
    print("S13_CONTRACT_RESULT ","PASS" if failed==0 else "FAIL"," ",checked," checks")
    quit(0 if failed==0 else 1)

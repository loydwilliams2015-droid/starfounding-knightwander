from pathlib import Path
import hashlib
import json
from PIL import Image

ROOT = Path(__file__).resolve().parents[1]

def test_assets():
    paths = [ROOT / 'assets/knight_standing.png', ROOT / 'assets/knight_crouching.png']
    images = [Image.open(p).convert('RGBA') for p in paths]
    assert [a.size for a in images] == [(64,128),(64,80)]
    assert hashlib.sha256(images[0].tobytes()).digest() != hashlib.sha256(images[1].tobytes()).digest()
    for im in images:
        assert im.getchannel('A').getbbox()[-1] >= im.height - 6
        assert im.getchannel('A').getbbox() is not None
    return '2 distinct authored pose assets with foot-visible alpha'

def test_source():
    visual = (ROOT/'scripts/sk_pose_visual.gd').read_text()
    adapter = (ROOT/'scripts/sk_crouch_adapter.gd').read_text()
    world = (ROOT/'scripts/sk_demo_world.gd').read_text()
    assert 'texture = desired' in visual
    assert 'scale = Vector2.ONE' in visual
    assert 'texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST' in visual
    assert 'offset = Vector2(0.0, -float(texture.get_height()) * 0.5)' in visual
    assert 'stand_blocked' in adapter
    assert 'current_top: float = -crouched_height' in adapter
    assert 'target_top: float = -standing_height - headroom_padding' in adapter
    assert 'query.exclude = [body.get_rid()]' in adapter
    assert 'body.global_transform * Transform2D' in adapter
    assert 'intersect_shape(query, 1)' in adapter
    assert 'move_and_slide()' in world
    assert 'adapter.request_crouch(holding)' in world
    assert 'S4_RESULT:' in (ROOT/'tests/pose_runtime_test.gd').read_text()
    return 'pose states, clearance slab, nearest filter, native test script'

if __name__ == '__main__':
    checks = {'assets':test_assets(), 'code':test_source()}
    for label, outcome in checks.items():print('PASS',label,outcome)
    (ROOT/'tests/s4_static_results.json').write_text(json.dumps({'status':'PASS','checks':checks,'native_runtime':'NOT RUN'},indent=2)+'\n')

#!/usr/bin/env python3
"""S7 deterministic artifact/source QA; NOT a Godot execution certification."""
from pathlib import Path
from PIL import Image
import json, hashlib
R=Path(__file__).resolve().parents[1]

def main():
    contract=json.loads((R/'art_contract.json').read_text())
    assert contract['release']=='S7' and not contract['approved_sprite_recovered']
    expected=contract['assets']
    for name,info in expected.items():
        p=R/info['relative_path']; im=Image.open(p).convert('RGBA')
        assert list(im.size)==info['dimensions_px']
        assert list(im.getchannel('A').getbbox())==info['alpha_bbox_xyxy']
        assert hashlib.sha256(p.read_bytes()).hexdigest()==info['sha256']
        assert info['role']=='REFERENCE_ONLY_NOT_APPROVED_PRODUCTION_ART'
    assert expected['knight_standing.png']['sha256'] != expected['knight_crouching.png']['sha256']
    visual=(R/'scripts/sk_pose_visual.gd').read_text()
    adapter=(R/'scripts/sk_crouch_adapter.gd').read_text()
    test=(R/'tests/pose_runtime_test.gd').read_text()
    capture=(R/'tests/capture_pose_frames.gd').read_text()
    assert 'texture = selected' in visual and 'scale = Vector2.ONE' in visual
    assert 'offset = Vector2(0.0, -float(texture.get_height()) * 0.5)' in visual
    assert 'query.exclude = [body.get_rid()]' in adapter
    assert 'demo.set_physics_process(false)' in test
    assert 'blocked stand retains crouching source image' in test
    assert 'image.save_png(path)' in capture
    gif=Image.open(R/'previews/s7_crouch_clearance_offline.gif')
    assert gif.n_frames==10 and gif.size==(960,540)
    assert (R/'tools/build_runtime_gif.py').is_file()
    result={'release':'S7','status':'PASS','checks':15,'gif_frames':gif.n_frames,'godot_runtime':'NOT RUN','screenshot_evidence':'OFFLINE DIAGNOSTIC ONLY','approved_art':'NOT RECOVERED'}
    (R/'tests/s7_static_results.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))

if __name__=='__main__': main()

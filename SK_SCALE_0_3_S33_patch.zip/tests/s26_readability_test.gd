extends SceneTree
const SCENE = preload("res://scenes/sk_s25_visual_reintegration.tscn")
var assertions := 0
var failures := 0
func _initialize() -> void: call_deferred("run")
func check(value: bool, label: String) -> void:
    assertions += 1
    if not value:
        failures += 1
        push_error("S26 failed: " + label)
func frames(n:int) -> void:
    for i in range(n): await physics_frame
func run() -> void:
    var scene = SCENE.instantiate()
    root.add_child(scene)
    current_scene = scene
    await frames(8)
    var reference_rates := []
    for p in scene.background_layers: reference_rates.append(p.scroll_scale)
    for enabled in [false,true,false]:
        scene.set_readability_mode(enabled)
        check(scene.readability_mode == enabled, "mode identity")
        check(is_equal_approx(scene.background_layers[3].modulate.a, 0.52 if enabled else 1.0),"foliage alpha")
        check(is_equal_approx(scene.foreground.modulate.a, 0.55 if enabled else 1.0),"foreground alpha")
        check(is_equal_approx(scene.lights[0].energy, 0.765 if enabled else 0.9),"lamp energy")
        for i in range(4): check(scene.background_layers[i].scroll_scale == reference_rates[i],"parallax rate preserved")
        for x in [200.0,420.0,640.0]:
            for crouch in [false,true]:
                scene.set_preview(x,crouch,1.0)
                await frames(2)
                check(scene.demo.adapter.crouched == crouch or (not crouch and scene.demo.adapter.stand_blocked and scene.demo.adapter.crouched),"pose input or legitimately blocked standing")
                check(scene.demo.adapter.visual.pose_texture_verified(),"correct pose texture")
                check(scene.demo.adapter.pose_geometry_verified(),"collider unchanged")
                check(scene.demo.art_driver.is_visual_valid(),"visible pose overlay")
                check(scene.camera.zoom == Vector2.ONE,"native review zoom")
    print("S26_READABILITY_RESULT assertions=",assertions," failures=",failures)
    quit(0 if failures==0 else 1)

extends SceneTree
const SCENE = preload("res://scenes/sk_s25_visual_reintegration.tscn")
var count := 0
var fail := 0
func _initialize() -> void: call_deferred("run")
func verify(ok: bool, message: String) -> void:
    if ok: count += 1
    else:
        fail += 1
        push_error("S25 " + message)
func tick(n:int) -> void:
    for i in range(n): await physics_frame
func run() -> void:
    var scene = SCENE.instantiate()
    root.add_child(scene)
    current_scene=scene
    await tick(5)
    verify(scene.background_layers.size()==4,"four parallax depths")
    verify(scene.lights.size()==2,"dynamic light emitters")
    verify(scene.camera.get_parent()==scene.demo.actor,"camera follows actor")
    verify(scene.foreground.z_index>0,"foreground over character")
    for i in range(1,4):
        verify(scene.background_layers[i].scroll_scale.x>scene.background_layers[i-1].scroll_scale.x,"ordered parallax speed "+str(i))
    for z in [1.0,2.0]:
        for crouch in [false,true]:
            scene.set_preview(200.0,crouch,z)
            await tick(2)
            verify(scene.demo.adapter.crouched==crouch,"requested crouch state")
            verify(scene.demo.adapter.visual.pose_texture_verified(),"correct assigned pose texture")
            verify(scene.demo.art_driver.is_visual_valid(),"art overlay visible geometry integrity")
            verify(scene.demo.adapter.pose_geometry_verified(),"collider geometry invariant")
            verify(scene.camera.zoom.x==z,"camera zoom exact")
    print("S25_STAGE_RESULT checks=",count," failures=",fail)
    quit(0 if fail==0 else 1)

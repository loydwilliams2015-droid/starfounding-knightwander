extends SceneTree
const P=preload("res://scripts/sk_s21_profile.gd")
var checks:=0
var failed:=0
func _initialize()->void:call_deferred("run")
func check(condition:bool,message:String)->void:
    checks+=1
    if not condition:
        failed+=1
        push_error("S21 "+message)
func run()->void:
    check(P.FRAMES==[0,0,1,2,3,3,3,3],"Profile A frame order")
    check(P.SETTLE_A!=P.SETTLE_B,"separate settle assets")
    check(P.SETTLE_B.get_size()==Vector2(64,112),"settle canvas")
    check(P.COMPRESS.get_size()==Vector2(64,94),"compression canvas")
    check(P.CROUCH.get_size()==Vector2(64,80),"crouch canvas")
    for variant in 2:
        for facing in [false,true]:
            for frame in 8:
                var s:=Sprite2D.new()
                P.assign(s,frame,variant,facing)
                check(s.texture==P.select(frame,variant),"texture")
                check(s.offset==Vector2(0,-s.texture.get_height()/2.0),"foot origin")
                check(s.scale==Vector2.ONE,"scale")
                check(s.flip_h==facing,"facing")
                check(s.texture_filter==CanvasItem.TEXTURE_FILTER_NEAREST,"filter")
                s.free()
    print("S21_RESULT ","PASS" if failed==0 else "FAIL"," ",checks," checks")
    quit(0 if failed==0 else 1)

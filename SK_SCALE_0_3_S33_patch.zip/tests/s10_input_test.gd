extends SceneTree
## Real scene physics/update path driven through Input actions; no direct pose calls.
const SCENE = preload("res://scenes/sk_pose_demo.tscn")
var errors: Array[String] = []
var assertions := 0
func _initialize() -> void:
    call_deferred("run")
func verify(ok: bool, message: String) -> void:
    assertions += 1
    if ok: print("PASS ", message)
    else:
        push_error("FAIL " + message)
        errors.append(message)
func frames(n: int) -> void:
    for i in range(n): await physics_frame
func run() -> void:
    var demo := SCENE.instantiate()
    root.add_child(demo)
    current_scene = demo
    await frames(4)
    var actor: CharacterBody2D = demo.actor
    var pose: SKCrouchAdapter = demo.adapter
    verify(not pose.crouched and pose.visual.pose_texture_verified(), "standing starts with verified standing texture")
    Input.action_press("sk_crouch")
    await frames(3)
    verify(pose.crouched and pose.visual.texture == pose.visual.crouching_texture, "action crouch selects dedicated sprite")
    Input.action_press("sk_right")
    var initial_x := actor.position.x
    await frames(15)
    verify(actor.position.x > initial_x + 20, "input moves actor while crouched")
    verify(pose.crouched and pose.visual.scale == Vector2.ONE, "crouch movement never squashes artwork")
    Input.action_release("sk_right")
    # QA starts next phase below roof; direct setup position is isolated from the input-driven test assertions.
    actor.global_position = Vector2(650,450)
    actor.velocity = Vector2.ZERO
    await frames(3)
    Input.action_release("sk_crouch")
    await frames(3)
    verify(pose.stand_blocked and pose.crouched, "release crouch beneath ceiling preserves pose")
    verify(pose.visual.texture == pose.visual.crouching_texture, "blocked pose renders dedicated crouch art")
    Input.action_press("sk_crouch")
    Input.action_press("sk_left")
    var under_roof_x := actor.global_position.x
    await frames(95)
    Input.action_release("sk_left")
    Input.action_release("sk_crouch")
    await frames(4)
    verify(actor.global_position.x < under_roof_x - 100, "action movement exits obstacle area")
    verify(not pose.crouched and not pose.stand_blocked, "crouch release after exiting roof restores standing")
    verify(pose.visual.pose_texture_verified() and pose.visual.texture == pose.visual.standing_texture, "actual assigned standing texture restored")
    verify(pose.visual.flip_h, "leftward action uses horizontal flip")
    Input.action_press("sk_right")
    await frames(3)
    Input.action_release("sk_right")
    verify(not pose.visual.flip_h, "rightward action removes horizontal flip")
    # Validate jump input in open space, from grounded standing state.
    actor.global_position = Vector2(240,450)
    actor.velocity = Vector2.ZERO
    await frames(4)
    verify(actor.is_on_floor(), "standing actor settles on floor")
    Input.action_press("sk_jump")
    await frames(2)
    Input.action_release("sk_jump")
    verify(actor.velocity.y < 0.0, "jump action launches standing actor")
    verify(pose.visual.pose_texture_verified(), "jump leaves selected standing art valid")
    for action in ["sk_crouch", "sk_left", "sk_right", "sk_jump"]: Input.action_release(action)
    print("S10_INPUT_RESULT ", "PASS" if errors.is_empty() else "FAIL", " ", assertions, " assertions")
    quit(0 if errors.is_empty() else 1)

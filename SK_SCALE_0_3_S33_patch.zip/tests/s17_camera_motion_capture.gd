extends SceneTree
## Real Godot 4.7.2 renderer captures, using QA player's crouched movement and tracking camera.
const SCENE = preload("res://scenes/sk_pose_demo.tscn")
const ZOOMS = [1.0, 1.5, 2.0]
var captures := 0
func _initialize() -> void: call_deferred("run")
func frames(n: int) -> void:
    for i in n: await physics_frame
func run() -> void:
    root.content_scale_size = Vector2i(960,540)
    var demo = SCENE.instantiate()
    root.add_child(demo)
    current_scene = demo
    await frames(5)
    var actor: CharacterBody2D = demo.actor
    var pose: SKCrouchAdapter = demo.adapter
    var camera := Camera2D.new()
    demo.add_child(camera)
    camera.position_smoothing_enabled = false
    camera.make_current()
    # A stationary WORLD-space stripe grid makes pixel-phase drift observable.
    var grid := Node2D.new()
    grid.z_index = -5
    demo.add_child(grid)
    for i in 45:
        var line := Line2D.new()
        var x := float(i*32-320)
        line.add_point(Vector2(x,180))
        line.add_point(Vector2(x,450))
        line.width = 1.0
        line.default_color = Color(0.34,0.47,0.52,0.7)
        grid.add_child(line)
    var label := Label.new()
    label.position=Vector2(20,135)
    label.add_theme_font_size_override("font_size",16)
    demo.hud.get_parent().add_child(label)
    DirAccess.make_dir_recursive_absolute(ProjectSettings.globalize_path("res://captures/s17_engine"))
    Input.action_press("sk_crouch")
    for z in ZOOMS:
        actor.global_position=Vector2(165,450)
        actor.velocity=Vector2.ZERO
        camera.zoom=Vector2(z,z)
        Input.action_press("sk_right")
        for step in 6:
            await frames(3)
            camera.global_position=actor.global_position+Vector2(0,-52)
            label.text="S17 SCROLL STUDY | %.2fx | step %d/6 | A PROFILE | REFERENCE ART" % [z,step+1]
            if not pose.crouched or not pose.visual.pose_texture_verified() or not pose.pose_geometry_verified():
                push_error("S17 capture failed pose validation")
                quit(1)
                return
            await process_frame
            await RenderingServer.frame_post_draw
            var im := root.get_viewport().get_texture().get_image()
            var filename := "res://captures/s17_engine/zoom_%03d_step_%02d.png" % [roundi(z*100),step]
            if im.get_width()!=960 or im.get_height()!=540 or im.save_png(filename)!=OK:
                push_error("S17 capture write failed: "+filename)
                quit(1)
                return
            captures+=1
        Input.action_release("sk_right")
    Input.action_release("sk_crouch")
    print("S17_MOTION_CAPTURE PASS %d frames" % captures)
    quit(0)

#!/usr/bin/env python3
"""S6 source-asset acceptance checks; not a substitute for running Godot."""
from pathlib import Path
from PIL import Image
import hashlib,json
ROOT=Path(__file__).resolve().parents[1]

def run():
    contract=json.loads((ROOT/'art_contract.json').read_text())
    assert contract['release']=='S6'
    assert contract['approved_sprite_recovered'] is False
    scans={}
    for name,item in contract['assets'].items():
        p=ROOT/item['relative_path']; im=Image.open(p).convert('RGBA')
        assert list(im.size)==item['dimensions_px']
        assert list(im.getchannel('A').getbbox())==item['alpha_bbox_xyxy']
        digest=hashlib.sha256(p.read_bytes()).hexdigest()
        assert digest==item['sha256']
        assert item['role']=='REFERENCE_ONLY_NOT_APPROVED_PRODUCTION_ART'
        assert im.getchannel('A').getbbox()[3]>=im.height-6
        scans[name]={'size':list(im.size),'sha256':digest,'visible_bbox':list(im.getchannel('A').getbbox())}
    assert scans['knight_standing.png']['sha256']!=scans['knight_crouching.png']['sha256']
    visual=(ROOT/'scripts/sk_pose_visual.gd').read_text()
    adapter=(ROOT/'scripts/sk_crouch_adapter.gd').read_text()
    native=(ROOT/'tests/pose_runtime_test.gd').read_text()
    assert 'texture.resource_path' in visual
    assert 'return "res://assets/knight_crouching.png" if crouched' not in visual
    assert 'flip_h = value' in visual and 'scale = Vector2.ONE' in visual
    assert 'query.exclude = [body.get_rid()]' in adapter
    assert 'roof edge blocks premature stand' in native
    assert 'stand recovers after moving out from under roof' in native
    assert (ROOT/'previews/s6_actual_source_pose_review.png').exists()
    return {'status':'PASS','static_checks':12,'sources':scans,'native_godot':'NOT RUN','production_art':'NOT APPROVED'}
if __name__=='__main__':
    result=run(); (ROOT/'tests/s6_static_results.json').write_text(json.dumps(result,indent=2)+'\n'); print(json.dumps(result,indent=2))

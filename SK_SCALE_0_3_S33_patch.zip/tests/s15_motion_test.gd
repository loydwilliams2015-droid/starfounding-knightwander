extends SceneTree
## S15: keyed Profile A moving/facing trajectory must remain pose-correct.
const POSES = [preload("res://assets/knight_standing.png"), preload("res://assets/knight_transition_settle.png"), preload("res://assets/knight_transition_compress.png"), preload("res://assets/knight_crouching.png")]
const FRAMES = [0, 0, 1, 2, 3, 3, 3, 3, 3, 3, 2, 1, 0, 0]
const X_POS = [90, 102, 114, 126, 138, 150, 162, 174, 186, 174, 162, 150, 138, 126]
var checked := 0
var failed := 0
func _initialize() -> void: call_deferred("run")
func verify(ok: bool, why: String) -> void:
    checked += 1
    if not ok:
        failed += 1
        push_error("S15 FAIL: " + why)
func run() -> void:
    verify(FRAMES.size() == X_POS.size(), "frame/trajectory lengths")
    verify(FRAMES.count(2) == 2, "one compression frame each direction")
    verify(FRAMES[4] == 3 and FRAMES[12] == 0, "pose endpoint schedule")
    for i in FRAMES.size():
        var pose: int = FRAMES[i]
        var sprite := Sprite2D.new()
        sprite.texture = POSES[pose]
        sprite.centered = true
        sprite.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
        sprite.offset = Vector2(0.0, -float(sprite.texture.get_height()) / 2.0)
        sprite.position = Vector2(float(X_POS[i]), 410.0)
        sprite.flip_h = i >= 9
        verify(sprite.scale == Vector2.ONE, "native scale %d" % i)
        verify(sprite.position.y == 410.0, "feet at same world y %d" % i)
        verify(is_equal_approx(sprite.offset.y, -sprite.texture.get_height() / 2.0), "bottom center origin %d" % i)
        verify(sprite.flip_h == (i >= 9), "facing contract %d" % i)
        verify(sprite.texture.get_width() == 64, "authored width %d" % i)
        verify(sprite.texture.get_image().get_used_rect().has_area(), "visible art %d" % i)
        sprite.free()
    print("S15_MOTION_RESULT ", "PASS" if failed == 0 else "FAIL", " ", checked, " checks")
    quit(0 if failed == 0 else 1)

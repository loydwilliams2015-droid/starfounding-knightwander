extends SceneTree
const SCENE = preload("res://scenes/sk_s25_visual_reintegration.tscn")
var checks := 0
var failures := 0
func check(ok: bool, message: String) -> void:
    checks += 1
    if not ok:
        failures += 1
        push_error("S30 FAIL: " + message)
func physics(n: int) -> void:
    for i in range(n): await physics_frame
func run() -> void:
    var stage = SCENE.instantiate()
    root.add_child(stage)
    current_scene = stage
    await physics(12)
    stage.demo.actor.global_position = Vector2(1200,450)
    stage.demo.actor.velocity = Vector2.ZERO
    await physics(10)
    check(stage.demo.actor.is_on_floor(), "start on connected ground")
    check(stage.s30_camera_diagnostics().parallax_count == 4, "four parallax layers")
    Input.action_press("sk_right")
    await physics(18)
    check(stage.s29_camera_diagnostics().lookahead_x > 0.0, "horizontal lookahead retained")
    Input.action_release("sk_right")
    stage.demo.actor.global_position = Vector2(1600,450)
    stage.demo.actor.velocity = Vector2.ZERO
    await physics(5)
    stage.demo.jump_queued = true
    await physics(5)
    var rise = stage.s30_camera_diagnostics()
    check(rise.airborne, "jump reaches airborne state")
    check(rise.velocity_y < 0.0, "rising vertical velocity")
    check(rise.vertical_offset < -0.1, "camera anticipates rise")
    check(rise.vertical_offset >= -46.01, "upward framing bounded")
    await physics(28)
    var fall = stage.s30_camera_diagnostics()
    check(fall.vertical_offset > rise.vertical_offset, "vertical framing follows falling arc")
    check(fall.vertical_offset <= 64.01, "downward framing bounded")
    await physics(36)
    Input.action_release("sk_right")
    check(stage.demo.actor.is_on_floor(), "landing on connected ground")
    await physics(42)
    check(absf(stage.s30_camera_diagnostics().vertical_offset) < 2.0, "vertical framing recenters after landing")
    check(stage.demo.adapter.pose_geometry_verified(), "pose geometry intact")
    check(stage.demo.art_driver.is_visual_valid(), "visual layer intact")
    stage.set_camera_tracking_phase(31.5, false)
    check(not stage.s30_vertical_enabled, "S27 manual tracking owns camera")
    check(is_equal_approx(stage.camera.offset.y, sin(31.5 / 110.0) * 2.0), "manual camera phase unchanged")
    print("S30_RESULT checks=",checks," failures=",failures)
    quit(0 if failures == 0 else 1)
func _initialize() -> void: call_deferred("run")

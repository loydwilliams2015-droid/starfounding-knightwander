extends SceneTree
const SCENE = preload("res://scenes/sk_s25_visual_reintegration.tscn")
const OUT = "res://captures/s30_engine/"
var errors := 0
func physics(n: int) -> void:
    for i in range(n): await physics_frame
func frames(n: int) -> void:
    for i in range(n): await process_frame
func snap(stage, name: String) -> void:
    await frames(3)
    var image = root.get_texture().get_image()
    var err = image.save_png(ProjectSettings.globalize_path(OUT + name + ".png"))
    if err != OK or image.get_size() != Vector2i(960,540): errors += 1
    print("S30_CAPTURE ",name," camera_y=",stage.camera.offset.y," actor_y=",stage.demo.actor.global_position.y," err=",err)
func run() -> void:
    var stage=SCENE.instantiate()
    root.add_child(stage)
    current_scene=stage
    await frames(16)
    stage.set_readability_mode(true)
    stage.set_surface_separation(true)
    stage.demo.actor.global_position=Vector2(1200,450)
    await physics(12)
    await snap(stage,"01_grounded")
    Input.action_press("sk_right")
    await physics(18)
    await snap(stage,"02_running")
    Input.action_release("sk_right")
    stage.demo.actor.global_position=Vector2(1600,450)
    stage.demo.actor.velocity=Vector2.ZERO
    await physics(5)
    stage.demo.jump_queued=true
    await physics(1)
    for i in range(6):
        await physics(9)
        await snap(stage,"%02d_jump" % (i+3))
    Input.action_release("sk_right")
    await physics(40)
    await snap(stage,"09_landed")
    await physics(28)
    await snap(stage,"10_recentered")
    print("S30_CAPTURE_RESULT errors=",errors)
    quit(0 if errors==0 else 1)
func _initialize() -> void: call_deferred("run")

extends SceneTree
## Native Godot regressions for S11 art invariants and repeated pose change.
const SCENE = preload("res://scenes/sk_pose_demo.tscn")
var checks := 0
var failures: Array[String] = []
func _initialize() -> void: call_deferred("run")
func verify(condition: bool, label: String) -> void:
    checks += 1
    if not condition:
        failures.append(label)
        push_error("FAIL " + label)
    else:
        print("PASS ", label)
func frames(n: int) -> void:
    for i in range(n): await physics_frame
func run() -> void:
    var demo = SCENE.instantiate()
    root.add_child(demo)
    current_scene = demo
    await frames(5)
    var adapter: SKCrouchAdapter = demo.adapter
    var visual: SKPoseVisual = adapter.visual
    var actor: CharacterBody2D = demo.actor
    verify(visual.pose_texture_verified(), "idle standing art invariant")
    Input.action_press("sk_crouch")
    await frames(4)
    verify(adapter.crouched and visual.pose_texture_verified(), "input crouch invariant")
    var base_y = actor.global_position.y
    visual.offset = Vector2(12, 12)
    verify(not visual.pose_texture_verified(), "detect displaced sprite anchor")
    adapter.request_crouch(true)
    verify(visual.pose_texture_verified() and visual.offset.is_equal_approx(Vector2(0,-40)), "restore crouch foot anchor")
    visual.texture_filter = CanvasItem.TEXTURE_FILTER_LINEAR
    verify(not visual.pose_texture_verified(), "detect incorrect filtering")
    adapter.request_crouch(true)
    verify(visual.pose_texture_verified(), "restore nearest filter")
    visual.flip_h = not visual.facing_left
    verify(not visual.pose_texture_verified(), "detect facing desync")
    adapter.request_crouch(true)
    verify(visual.pose_texture_verified(), "restore facing")
    visual.texture = visual.standing_texture
    verify(not visual.pose_texture_verified(), "detect stale standing texture while crouched")
    adapter.request_crouch(true)
    verify(visual.texture == visual.crouching_texture and visual.pose_texture_verified(), "restore dedicated crouching sprite")
    verify(is_equal_approx(actor.global_position.y, base_y), "art repair does not move physics actor")
    var expected_rect = (adapter.collider.shape as RectangleShape2D)
    verify(is_equal_approx(expected_rect.size.y, adapter.crouched_height), "crouch collider remains exact")
    # Repeated input-driven transitions with no scene reload or collider drift.
    Input.action_release("sk_crouch")
    await frames(4)
    verify(not adapter.crouched and visual.pose_texture_verified(), "return to stand through input")
    for i in range(40):
        Input.action_press("sk_crouch")
        await frames(2)
        verify(adapter.crouched and visual.pose_texture_verified(), "repeated crouch %02d" % i)
        Input.action_release("sk_crouch")
        await frames(2)
        verify(not adapter.crouched and visual.pose_texture_verified(), "repeated stand %02d" % i)
    verify(is_equal_approx((adapter.collider.shape as RectangleShape2D).size.y, adapter.standing_height), "standing collider size after 40 transitions")
    verify(adapter.collider.position.is_equal_approx(Vector2(0,-adapter.standing_height*0.5)), "standing collider stays foot anchored")
    Input.action_press("sk_crouch")
    await frames(3)
    Input.action_press("sk_jump")
    await frames(2)
    Input.action_release("sk_jump")
    verify(adapter.crouched and actor.velocity.y >= -0.01, "jump suppressed while crouched")
    Input.action_release("sk_crouch")
    print("S11_ART_RESULT ", "PASS" if failures.is_empty() else "FAIL", " ", checks, " checks")
    quit(0 if failures.is_empty() else 1)

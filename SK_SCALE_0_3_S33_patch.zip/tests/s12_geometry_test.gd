extends SceneTree
const SCENE = preload("res://scenes/sk_pose_demo.tscn")
var checks := 0
var failures: Array[String] = []
func _initialize() -> void: call_deferred("run")
func verify(ok: bool, label: String) -> void:
    checks += 1
    if not ok:
        failures.append(label)
        push_error("FAIL " + label)
func ticks(n: int) -> void:
    for i in range(n): await physics_frame
func run() -> void:
    var demo := SCENE.instantiate()
    root.add_child(demo)
    current_scene = demo
    await ticks(4)
    var p: SKCrouchAdapter = demo.adapter
    var rect: RectangleShape2D = p.collider.shape as RectangleShape2D
    verify(p.pose_geometry_verified(), "standing geometry")
    var preserved_shape := p.collider.shape
    rect.size = Vector2(99, 12)
    p.collider.position = Vector2(6, 2)
    verify(not p.pose_geometry_verified(), "detect standing corruption")
    verify(p.repair_pose_geometry(), "repair standing corruption")
    verify(p.collider.shape == preserved_shape, "preserve collision resource identity")
    Input.action_press("sk_crouch")
    await ticks(4)
    verify(p.crouched and p.pose_geometry_verified(), "input crouch geometry")
    rect.size = Vector2(99, 12)
    p.collider.position = Vector2(5, 5)
    verify(not p.pose_geometry_verified(), "detect crouched corruption")
    await ticks(3)
    verify(p.pose_geometry_verified(), "input loop repairs geometry")
    verify(p.visual.pose_texture_verified(), "sprite integrity after repair")
    verify(p.collider.shape == preserved_shape, "no collider allocation during repair")
    Input.action_release("sk_crouch")
    await ticks(4)
    verify(not p.crouched and p.pose_geometry_verified(), "standing after repair")
    for i in range(30):
        Input.action_press("sk_crouch")
        await ticks(2)
        verify(p.crouched and p.pose_geometry_verified() and p.visual.pose_texture_verified(), "crouch cycle %d" % i)
        Input.action_release("sk_crouch")
        await ticks(2)
        verify(not p.crouched and p.pose_geometry_verified() and p.visual.pose_texture_verified(), "stand cycle %d" % i)
    print("S12_GEOMETRY_RESULT ", "PASS" if failures.is_empty() else "FAIL", " ", checks, " checks")
    quit(0 if failures.is_empty() else 1)

extends SceneTree
const SCENE = preload("res://scenes/sk_s25_visual_reintegration.tscn")
const OUT = "res://captures/s25_engine/"
func _initialize() -> void: call_deferred("run")
func tick(n:int) -> void:
    for i in range(n): await process_frame
func run() -> void:
    var scene=SCENE.instantiate()
    root.add_child(scene)
    current_scene=scene
    await tick(10)
    var specs=[
      ["01_standing_1x",200.0,false,1.0],
      ["02_crouching_1x",200.0,true,1.0],
      ["03_town_1x",540.0,false,1.0],
      ["04_town_crouch_1x",540.0,true,1.0],
      ["05_standing_2x",200.0,false,2.0],
      ["06_crouching_2x",200.0,true,2.0]
    ]
    var errors:=0
    for spec in specs:
        scene.set_preview(spec[1],spec[2],spec[3])
        await tick(6)
        var img=get_root().get_texture().get_image()
        var result=img.save_png(ProjectSettings.globalize_path(OUT+spec[0]+".png"))
        if result!=OK: errors+=1
        print("S25_CAPTURE ",spec[0]," ",img.get_width(),"x",img.get_height()," result=",result)
    quit(0 if errors==0 else 1)

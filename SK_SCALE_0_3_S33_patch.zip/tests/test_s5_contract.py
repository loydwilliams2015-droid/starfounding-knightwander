#!/usr/bin/env python3
"""S5 asset and source tests: not a substitute for the Godot native physics test."""
from pathlib import Path
import hashlib, json, zipfile
from PIL import Image
ROOT = Path(__file__).resolve().parents[1]

def run():
    m = json.loads((ROOT/'art_contract.json').read_text())
    assert m['approved_sprite_recovered'] is False
    assert len(m['assets']) == 2
    for name,info in m['assets'].items():
        p = ROOT/info['relative_path']
        assert p.is_file() and hashlib.sha256(p.read_bytes()).hexdigest() == info['sha256']
        with Image.open(p) as image:
            im=image.convert('RGBA'); bbox=im.getchannel('A').getbbox()
            assert list(im.size)==info['dimensions_px']
            assert list(bbox)==info['alpha_bbox_xyxy']
            assert bbox[3]>=im.height-6, 'foot artwork not at bottom anchor'
            assert bbox[0]>=0 and bbox[2]<=im.width
            assert im.getchannel('A').getextrema()[0]==0, 'requires transparent pixels'
        assert info['role']=='REFERENCE_ONLY_NOT_APPROVED_PRODUCTION_ART'
    assert m['assets']['knight_standing.png']['sha256']!=m['assets']['knight_crouching.png']['sha256']
    v=(ROOT/'scripts/sk_pose_visual.gd').read_text()
    a=(ROOT/'scripts/sk_crouch_adapter.gd').read_text()
    w=(ROOT/'scripts/sk_demo_world.gd').read_text()
    native=(ROOT/'tests/pose_runtime_test.gd').read_text()
    checks={
      'separate_authored_textures':'texture = selected' in v and 'crouching_texture if crouched else standing_texture' in v,
      'no_art_scaling':'scale = Vector2.ONE' in v and 'flip_h = value' in v and 'scale.x' not in w,
      'foot_anchor':'offset = Vector2(0.0, -float(texture.get_height()) * 0.5)' in v,
      'point_filter':'TEXTURE_FILTER_NEAREST' in v,
      'ceiling_slab':'current_top: float = -crouched_height' in a and 'target_top: float = -standing_height - headroom_padding' in a,
      'body_exclusion':'query.exclude = [body.get_rid()]' in a,
      'movement_owner':'actor.move_and_slide()' in w and 'move_and_slide' not in a,
      'runtime_facing_tests':'left facing mirrors via flip_h only' in native and 'right facing resets flip_h' in native,
      'runtime_headroom_tests':'stand blocked beneath roof' in native and 'stand allowed outside roof on ground' in native,
      'resource_readout':'current_asset_path()' in w,
    }
    assert all(checks.values()),checks
    return {'status':'PASS','checks':checks,'sprites':list(m['assets']), 'native_godot':'NOT RUN'}

if __name__=='__main__':
    result=run()
    print(json.dumps(result,indent=2))
    (ROOT/'tests/s5_static_results.json').write_text(json.dumps(result,indent=2)+'\n')

extends SceneTree
const Profile = preload("res://scripts/sk_s19_profile.gd")
const ZOOMS := [1.0,2.0]
const BACKGROUNDS := [Color("#1a2630"),Color("#87918d")]
var sprites: Array[Sprite2D] = []
var labels: Array[Label] = []
var count := 0
func _initialize() -> void: call_deferred("run")
func rectangle(parent: Node, rect: Rect2, color: Color) -> void:
    var p := Polygon2D.new()
    p.polygon = PackedVector2Array([rect.position,rect.position+Vector2(rect.size.x,0),rect.end,rect.position+Vector2(0,rect.size.y)])
    p.color=color
    p.z_index=-5
    parent.add_child(p)
func run() -> void:
    root.content_scale_size=Vector2i(960,540)
    var scene:=Node2D.new()
    root.add_child(scene)
    current_scene=scene
    var panels: Array[Node2D]=[]
    for index in 2:
        var panel:=Node2D.new()
        panel.position=Vector2(index*480,0)
        scene.add_child(panel)
        panels.append(panel)
        var label:=Label.new()
        label.position=Vector2(22,24)
        label.add_theme_font_size_override("font_size",20)
        panel.add_child(label)
        labels.append(label)
        var sprite:=Sprite2D.new()
        sprite.position=Vector2(240,345)
        panel.add_child(sprite)
        sprites.append(sprite)
    DirAccess.make_dir_recursive_absolute(ProjectSettings.globalize_path("res://captures/s19_engine"))
    for bg in 2:
        for zoom in ZOOMS:
            for frame in 8:
                for side in 2:
                    var panel:Node2D=panels[side]
                    for child in panel.get_children():
                        if child is Polygon2D:
                            child.queue_free()
                    rectangle(panel,Rect2(0,0,480,540),BACKGROUNDS[bg])
                    rectangle(panel,Rect2(0,346,480,10),Color("#536a6e") if bg==0 else Color("#424c50"))
                    var sprite:Sprite2D=sprites[side]
                    Profile.apply_to(sprite,frame,side==1,frame>=5)
                    sprite.scale=Vector2(zoom,zoom) # Review-only presentation zoom, never runtime actor scaling.
                    sprite.offset=Vector2(0,-float(sprite.texture.get_height())*0.5)
                    # To keep foot at the same screen position across review zoom, Sprite2D transforms about origin.
                    labels[side].text=("S18 BASELINE" if side==0 else "S19 TRIAL")+" | A | %dx"%int(zoom)
                for j in 3: await process_frame
                await RenderingServer.frame_post_draw
                var shot:=root.get_viewport().get_texture().get_image()
                var target: String = "res://captures/s19_engine/bg%d_zoom%d_frame%02d.png"%[bg,int(zoom),frame]
                if shot.get_width()!=960 or shot.get_height()!=540 or shot.save_png(target)!=OK:
                    push_error("S19 capture failed "+target)
                    quit(1)
                    return
                count+=1
    print("S19_CAPTURE_RESULT PASS ",count," frames")
    quit(0)

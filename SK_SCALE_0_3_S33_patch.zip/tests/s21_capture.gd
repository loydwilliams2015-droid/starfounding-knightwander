extends SceneTree
const P=preload("res://scripts/sk_s21_profile.gd")
var root_world:Node2D
var labels:Array[Label]=[]
var sprites:Array[Sprite2D]=[]
var n:=0
func _initialize()->void: call_deferred("run")
func polygon(parent:Node2D,pts:PackedVector2Array,color:Color,z:int=-5)->void:
    var p:=Polygon2D.new()
    p.polygon=pts
    p.color=color
    p.z_index=z
    parent.add_child(p)
func rectangle(parent:Node2D,x:float,y:float,w:float,h:float,color:Color,z:int=-5)->void:
    polygon(parent,PackedVector2Array([Vector2(x,y),Vector2(x+w,y),Vector2(x+w,y+h),Vector2(x,y+h)]),color,z)
func run()->void:
    root.content_scale_size=Vector2i(960,540)
    root_world=Node2D.new()
    root.add_child(root_world)
    current_scene=root_world
    for v in 2:
        var panel:=Node2D.new()
        panel.position=Vector2(v*480,0)
        root_world.add_child(panel)
        rectangle(panel,0,0,480,540,Color("#1c2c36"))
        # Original procedural level backdrop: stone arcade, foliage, torch and layered floor.
        for i in 6:
            rectangle(panel,float(i*84),60,5,310,Color("#324450"))
            rectangle(panel,float(i*84-14),79,34,8,Color("#617179"))
        for j in 5:
            rectangle(panel,float(j*110),340,75,10,Color("#506870"))
            rectangle(panel,float(j*110+7),360,55,7,Color("#273d45"))
        rectangle(panel,0,407,480,133,Color("#293f3e"))
        rectangle(panel,0,395,480,12,Color("#71837c"))
        rectangle(panel,40,190,80,5,Color("#89918c"))
        rectangle(panel,342,205,98,5,Color("#89918c"))
        rectangle(panel,206,115,5,255,Color("#56716c"))
        rectangle(panel,196,173,25,6,Color("#b9985e"))
        var s:=Sprite2D.new()
        s.position=Vector2(245,394)
        panel.add_child(s)
        sprites.append(s)
        var l:=Label.new()
        l.position=Vector2(14,14)
        l.add_theme_font_size_override("font_size",18)
        panel.add_child(l)
        labels.append(l)
    DirAccess.make_dir_recursive_absolute(ProjectSettings.globalize_path("res://captures/s21_engine"))
    for frame in 8:
        for v in 2:
            P.assign(sprites[v],frame,v,frame>=5)
            labels[v].text=("S20 SETTLE" if v==0 else "S21 SETTLE TRIAL")+" / A POSE "+str(frame)
        for j in 3: await process_frame
        await RenderingServer.frame_post_draw
        var pic:=root.get_viewport().get_texture().get_image()
        if pic.get_width()!=960 or pic.get_height()!=540 or pic.save_png("res://captures/s21_engine/frame_%02d.png"%frame)!=OK:
            push_error("S21 capture failed")
            quit(1)
            return
        n+=1
    print("S21_CAPTURE PASS ",n," frames")
    quit(0)

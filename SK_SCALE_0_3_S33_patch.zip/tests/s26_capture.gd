extends SceneTree
const SCENE = preload("res://scenes/sk_s25_visual_reintegration.tscn")
const OUT = "res://captures/s26_engine/"
func _initialize() -> void: call_deferred("run")
func tick(n: int) -> void:
    for i in range(n): await process_frame
func run() -> void:
    var scene = SCENE.instantiate()
    root.add_child(scene)
    current_scene = scene
    await tick(14)
    var failures := 0
    for tuned in [false,true]:
        scene.set_readability_mode(tuned)
        for pos in [200.0,340.0,480.0,620.0]:
            scene.set_preview(pos,true,1.0)
            await tick(5)
            var picture := root.get_texture().get_image()
            var name := ("tuned_" if tuned else "baseline_") + str(int(pos)) + ".png"
            var result := picture.save_png(ProjectSettings.globalize_path(OUT+name))
            if result != OK: failures += 1
            print("S26_CAPTURE ",name," ",picture.get_width(),"x",picture.get_height()," result=",result)
    quit(0 if failures==0 else 1)

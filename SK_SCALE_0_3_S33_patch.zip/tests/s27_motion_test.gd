extends SceneTree
const SCENE = preload("res://scenes/sk_s25_visual_reintegration.tscn")
var assertions := 0
var failures := 0
func check(ok: bool, label: String) -> void:
    assertions += 1
    if not ok:
        failures += 1
        push_error("S27: " + label)
func frames(n: int) -> void:
    for i in range(n): await physics_frame
func run() -> void:
    var scene = SCENE.instantiate()
    root.add_child(scene)
    current_scene = scene
    await frames(10)
    scene.set_readability_mode(true)
    scene.set_surface_separation(true)
    check(scene.background_layers.size() == 4, "four layers")
    check(scene.foreground.modulate.a < scene.background_layers[3].modulate.a, "foreground lightened")
    check(scene.background_layers[2].modulate.a < 0.82, "architecture recedes")
    for i in range(3):
        check(scene.background_layers[i].scroll_scale.x < scene.background_layers[i+1].scroll_scale.x, "ordered depth "+str(i))
    scene.set_preview(340.0, true, 1.0)
    await frames(6)
    var last_x := -99999.0
    for step in range(20):
        var phase := float(step) * 3.25
        scene.set_camera_tracking_phase(phase, true)
        await frames(2)
        var x: float = scene.camera.offset.x
        check(is_equal_approx(x,round(phase)), "pixel snapped camera "+str(step))
        check(x >= last_x, "monotonic scroll "+str(step))
        last_x = x
        check(scene.demo.adapter.crouched, "crouched unchanged "+str(step))
        check(scene.demo.adapter.pose_geometry_verified(), "geometry "+str(step))
        check(scene.demo.adapter.visual.pose_texture_verified(), "texture "+str(step))
        check(scene.demo.art_driver.is_visual_valid(), "overlay "+str(step))
    scene.set_camera_tracking_phase(10.25, false)
    check(is_equal_approx(scene.camera.offset.x,10.25), "unsnapped experimental camera")
    scene.set_surface_separation(false)
    check(is_equal_approx(scene.foreground.modulate.a,0.55), "revert foreground")
    print("S27_MOTION_RESULT assertions=",assertions," failures=",failures)
    quit(0 if failures==0 else 1)
func _initialize() -> void: call_deferred("run")

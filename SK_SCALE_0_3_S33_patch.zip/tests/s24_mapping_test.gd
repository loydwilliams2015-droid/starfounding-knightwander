extends SceneTree
const PROFILE = preload("res://scripts/sk_s22_profile.gd")
var passed := 0
var failed := 0
func check(ok: bool, label: String) -> void:
    if ok: passed += 1
    else:
        failed += 1
        push_error("S24 failed: " + label)
func _initialize() -> void:
    call_deferred("run")
func run() -> void:
    var atlas: Texture2D = load("res://assets/s24/profile_A_8x64x128.png")
    check(atlas.get_size() == Vector2(512,128), "atlas size")
    var seq := [0,0,1,2,3,3,3,3]
    var names := ["standing", "settling", "compression", "crouching"]
    var heights := [128,112,94,80]
    for i in range(8):
        check(PROFILE.FRAMES[i] == seq[i], "frame index " + str(i))
        var t: Texture2D = PROFILE.select(i,1)
        check(t.get_height() == heights[seq[i]], "pose height at " + str(i))
        var src: Image = t.get_image()
        src.convert(Image.FORMAT_RGBA8)
        var image: Image = atlas.get_image()
        image.convert(Image.FORMAT_RGBA8)
        var match_pixels := true
        for y in range(128):
            for x in range(64):
                var expected := Color.TRANSPARENT
                var local_y: int = y - (128 - heights[seq[i]])
                if local_y >= 0 and local_y < src.get_height(): expected = src.get_pixel(x,local_y)
                var actual := image.get_pixel(i*64+x,y)
                var delta := absf(actual.a - expected.a)
                if expected.a > 0.01:
                    delta = maxf(delta, absf(actual.r - expected.r))
                    delta = maxf(delta, absf(actual.g - expected.g))
                    delta = maxf(delta, absf(actual.b - expected.b))
                if delta > 0.012:
                    match_pixels = false
                    break
            if not match_pixels: break
        check(match_pixels,"atlas/source pixel identity at " + str(i))
    print("S24_MAPPING ", passed, " passed; ", failed, " failed")
    quit(0 if failed==0 else 1)

extends SceneTree
## Original SK keyframe study; detached from authoritative game collisions.
const STAND = preload("res://assets/knight_standing.png")
const SETTLE = preload("res://assets/knight_transition_settle.png")
const COMPRESS = preload("res://assets/knight_transition_compress.png")
const CROUCH = preload("res://assets/knight_crouching.png")
const IMAGES = [STAND, SETTLE, COMPRESS, CROUCH]
const NAMES = ["STAND", "SETTLE", "COMPRESS", "CROUCH"]
const PROFILES = [ [0,0,1,3,3,3,3,3], [0,1,1,2,2,3,3,3] ]
var sprites: Array[Sprite2D] = []
var panels: Array[Node2D] = []
var saved := 0
var pose_labels: Array[Label] = []
func _initialize() -> void: call_deferred("run")
func label_text(parent: Node, message: String, position: Vector2, size: int = 19) -> void:
    var l := Label.new()
    l.text = message
    l.position = position
    l.add_theme_font_size_override("font_size",size)
    parent.add_child(l)
func add_rect(parent: Node, x: float, y: float, w: float, h: float, color: Color) -> void:
    var p := Polygon2D.new()
    p.polygon = PackedVector2Array([Vector2(x,y),Vector2(x+w,y),Vector2(x+w,y+h),Vector2(x,y+h)])
    p.color = color
    parent.add_child(p)
func run() -> void:
    root.content_scale_size=Vector2i(960,540)
    var scene := Node2D.new()
    root.add_child(scene)
    current_scene=scene
    for col in range(2):
        var panel:=Node2D.new()
        panel.position=Vector2(col*480,0)
        scene.add_child(panel)
        panels.append(panel)
        add_rect(panel,0,0,480,540,Color("283846") if col==0 else Color("3c4a57"))
        add_rect(panel,25,404,430,8,Color("889e9a"))
        label_text(panel,["A / KEY-POSE EMPHASIS","B / INTERMEDIATE TIMING"][col],Vector2(28,35),21)
        label_text(panel,["X4-informed timing hypothesis","Dead Cells-informed timing hypothesis"][col],Vector2(28,74),17)
        label_text(panel,"Experiment / original SK artwork",Vector2(28,475),16)
        var state_label := Label.new()
        state_label.position = Vector2(28,435)
        state_label.add_theme_font_size_override("font_size",16)
        panel.add_child(state_label)
        pose_labels.append(state_label)
        var s:=Sprite2D.new()
        s.position=Vector2(238,402)
        s.texture_filter=CanvasItem.TEXTURE_FILTER_NEAREST
        panel.add_child(s)
        sprites.append(s)
    DirAccess.make_dir_recursive_absolute(ProjectSettings.globalize_path("res://captures/s13_engine"))
    for frame in range(8):
        for col in range(2):
            var idx: int=PROFILES[col][frame]
            var sprite:=sprites[col]
            sprite.texture=IMAGES[idx]
            sprite.offset=Vector2(0.0,-float(sprite.texture.get_height())*0.5)
            sprite.scale=Vector2.ONE
            pose_labels[col].text = "%s | frame %02d" % [NAMES[idx],frame]
        for t in range(3): await process_frame
        await RenderingServer.frame_post_draw
        var image:=root.get_viewport().get_texture().get_image()
        var err:=image.save_png("res://captures/s13_engine/frame_%02d.png"%frame)
        if err != OK:
            push_error("S13 screenshot failure")
            quit(1)
            return
        saved+=1
        print("S13_FRAME ",frame," ",IMAGES[PROFILES[0][frame]].resource_path.get_file()," / ",IMAGES[PROFILES[1][frame]].resource_path.get_file())
    print("S13_CAPTURE_RESULT PASS ",saved," engine frames")
    quit(0)

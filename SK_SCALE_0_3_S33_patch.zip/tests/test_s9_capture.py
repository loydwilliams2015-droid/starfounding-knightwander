#!/usr/bin/env python3
"""Inspect actual engine-generated PNG captures for geometry and pose changes."""
from pathlib import Path
from PIL import Image, ImageChops
import json
root=Path(__file__).resolve().parents[1]
dir=root/'captures/s9_engine'
files=[dir/f'{i:02d}_{name}.png' for i,name in enumerate(['stand','crouch','blocked','recovered'],1)]
frames=[Image.open(p).convert('RGB') for p in files]
checks={
    'all_four_frames_present':all(p.is_file() for p in files),
    'all_960x540': all(im.size==(960,540) for im in frames),
    'stand_crouch_pixels_differ': ImageChops.difference(frames[0],frames[1]).getbbox() is not None,
    'crouch_blocked_pixels_differ': ImageChops.difference(frames[1],frames[2]).getbbox() is not None,
    'blocked_recovery_pixels_differ': ImageChops.difference(frames[2],frames[3]).getbbox() is not None,
    'stand_recovery_pixels_differ': ImageChops.difference(frames[0],frames[3]).getbbox() is not None,
    'crouch_standing_source_distinct': (root/'assets/knight_crouching.png').read_bytes()!=(root/'assets/knight_standing.png').read_bytes(),
}
(root/'tests/s9_capture_results.json').write_text(json.dumps(checks,indent=2)+'\n')
for k,v in checks.items(): print(('PASS' if v else 'FAIL'),k)
if not all(checks.values()): raise SystemExit(1)

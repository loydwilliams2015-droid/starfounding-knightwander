extends SceneTree
const SCENE = preload("res://scenes/sk_s25_visual_reintegration.tscn")
var checks := 0
var errors := 0
func verify(ok:bool, label:String) -> void:
    checks += 1
    if not ok:
        errors += 1
        push_error("S28: " + label)
func step(n:int) -> void:
    for i in range(n): await physics_frame
func release_all() -> void:
    for action in ["sk_left","sk_right","sk_crouch","sk_jump"]: Input.action_release(action)
func run() -> void:
    var stage = SCENE.instantiate()
    root.add_child(stage)
    current_scene = stage
    await step(12)
    stage.set_readability_mode(true)
    stage.set_surface_separation(true)
    stage.demo.actor.global_position = Vector2(220,450)
    stage.demo.actor.velocity = Vector2.ZERO
    stage.set_camera_tracking_phase(0.0,true)
    await step(5)
    var initial_x:float = stage.demo.actor.global_position.x
    Input.action_press("sk_right")
    await step(24)
    Input.action_release("sk_right")
    var run_x:float = stage.demo.actor.global_position.x
    verify(run_x > initial_x + 25.0,"actual action moves actor")
    verify(stage.camera.global_position.distance_to(stage.demo.actor.global_position + Vector2(0,-105)) < 0.01,"camera parent follows actor")
    verify(stage.demo.adapter.pose_geometry_verified(),"running collision integrity")
    verify(stage.demo.art_driver.is_visual_valid(),"running overlay visible and valid")
    # Jump while standing in open terrain. Physics jump is a one-shot input.
    stage.demo.actor.global_position = Vector2(250,450)
    stage.demo.actor.velocity = Vector2.ZERO
    await step(6)
    var floor_y:float = stage.demo.actor.global_position.y
    stage.demo.jump_queued = true
    await step(2)
    verify(stage.demo.actor.velocity.y < 0.0,"jump launched")
    await step(8)
    verify(stage.demo.actor.global_position.y < floor_y - 10.0,"jump changes vertical position")
    verify(stage.demo.art_driver.is_visual_valid(),"jump visual integrity")
    verify(stage.demo.adapter.pose_geometry_verified(),"jump collider integrity")
    await step(70)
    verify(stage.demo.actor.is_on_floor(),"landing resolves")
    stage.demo.actor.global_position = Vector2(270,450)
    stage.demo.actor.velocity = Vector2.ZERO
    await step(4)
    Input.action_press("sk_crouch")
    Input.action_press("sk_right")
    await step(20)
    Input.action_release("sk_right")
    verify(stage.demo.adapter.crouched,"crouch input sets crouched")
    verify(stage.demo.adapter.visual.pose_texture_verified(),"dedicated crouch sprite")
    verify(stage.demo.art_driver.is_visual_valid(),"crouch overlay")
    verify(stage.demo.adapter.pose_geometry_verified(),"crouch collider")
    var shot:Dictionary = stage.s28_camera_snapshot()
    verify(shot.parallax_scales.size()==4,"four parallax layers")
    for i in range(3): verify(shot.parallax_scales[i] < shot.parallax_scales[i+1], "monotonic depth "+str(i))
    verify(stage.background_layers[2].modulate.a < 0.75,"architecture separation")
    verify(stage.foreground.modulate.a < 0.40,"foreground separation")
    verify(stage.demo.actor.global_position.x > 270.0,"crouch motion")
    Input.action_release("sk_crouch")
    await step(15)
    verify(not stage.demo.adapter.crouched,"standing recovered in open terrain")
    verify(stage.demo.art_driver.is_visual_valid(),"recover overlay")
    release_all()
    print("S28_INPUT_CAMERA_RESULT assertions=",checks," failures=",errors)
    quit(0 if errors==0 else 1)
func _initialize() -> void: call_deferred("run")

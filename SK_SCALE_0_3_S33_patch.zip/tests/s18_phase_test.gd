extends SceneTree
## Test camera phases never mutate the source texture, collider or sprite transform.
const SCENE = preload("res://scenes/sk_pose_demo.tscn")
var checks := 0
var fail := 0
func check(ok: bool, name: String) -> void:
    checks += 1
    if not ok:
        fail += 1
        push_error("S18 FAIL: "+name)
func _initialize() -> void: call_deferred("run")
func run() -> void:
    var demo = SCENE.instantiate()
    root.add_child(demo)
    current_scene = demo
    for i in 5: await physics_frame
    demo.set_physics_process(false)
    var actor: CharacterBody2D = demo.actor
    var adapter: SKCrouchAdapter = demo.adapter
    actor.global_position = Vector2(190,450)
    adapter.request_crouch(true)
    var cam := Camera2D.new()
    demo.add_child(cam)
    cam.make_current()
    for z in [1.0,1.5,2.0]:
        cam.zoom = Vector2(z,z)
        for p in [0.0,0.25,0.5,0.75]:
            cam.global_position = actor.global_position + Vector2(p,-60)
            await process_frame
            check(adapter.crouched, "crouched %.2f %.2f" % [z,p])
            check(adapter.visual.pose_texture_verified(), "texture %.2f %.2f" % [z,p])
            check(adapter.pose_geometry_verified(), "collider %.2f %.2f" % [z,p])
            check(adapter.visual.scale == Vector2.ONE, "unscaled sprite %.2f %.2f" % [z,p])
            check(adapter.visual.current_asset_path().ends_with("knight_crouching.png"), "source texture %.2f %.2f" % [z,p])
    print("S18_PHASE_TEST %s %d/%d" % ["PASS" if fail==0 else "FAIL",checks-fail,checks])
    quit(0 if fail==0 else 1)

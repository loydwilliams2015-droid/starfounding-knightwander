extends SceneTree
const Profile = preload("res://scripts/sk_s19_profile.gd")
var checks := 0
var failures := 0
func _initialize() -> void: call_deferred("run")
func check(ok: bool, label: String) -> void:
    checks += 1
    if not ok:
        failures += 1
        push_error("S19 FAIL: " + label)
func run() -> void:
    check(Profile.A_PROFILE == [0,0,1,2,3,3,3,3], "Profile A retained")
    check(Profile.BASE_COMPRESSION != Profile.TRIAL_COMPRESSION, "trial isolated from baseline")
    check(Profile.TRIAL_COMPRESSION.get_size()==Vector2(64,94), "trial dimensions")
    check(Profile.CROUCH.get_size()==Vector2(64,80), "authoritative crouch preserved")
    var trial_image: Image = Profile.TRIAL_COMPRESSION.get_image()
    var original_image: Image = Profile.BASE_COMPRESSION.get_image()
    check(trial_image.get_data()!=original_image.get_data(), "trial artwork actually changed")
    check(trial_image.get_used_rect().has_area(), "trial visible")
    check(trial_image.get_used_rect().end.y >= 92, "trial reaches foot baseline")
    for face in [false,true]:
        for i in 8:
            for trial in [false,true]:
                var sprite := Sprite2D.new()
                Profile.apply_to(sprite,i,trial,face)
                check(sprite.texture==Profile.texture_for_frame(i,trial), "source selection")
                check(sprite.offset==Vector2(0.0,-float(sprite.texture.get_height())/2.0), "feet anchored")
                check(sprite.scale==Vector2.ONE and sprite.flip_h==face, "no deformation and facing")
                check(sprite.texture_filter==CanvasItem.TEXTURE_FILTER_NEAREST, "sharp filtering")
                sprite.free()
    print("S19_ART_RESULT ","PASS" if failures==0 else "FAIL", " ",checks," checks")
    quit(0 if failures==0 else 1)

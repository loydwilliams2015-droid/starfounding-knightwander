extends SceneTree
const SCENE = preload("res://scenes/sk_s25_visual_reintegration.tscn")
var checks := 0
var failures := 0
func verify(ok: bool, desc: String) -> void:
    checks += 1
    if not ok:
        failures += 1
        push_error("S29: " + desc)
func physics(n:int) -> void:
    for i in range(n): await physics_frame
func run() -> void:
    var stage = SCENE.instantiate()
    root.add_child(stage)
    current_scene = stage
    await physics(12)
    stage.set_readability_mode(true)
    stage.set_surface_separation(true)
    stage.demo.actor.global_position=Vector2(1030,450)
    stage.demo.actor.velocity=Vector2.ZERO
    await physics(8)
    var start_x=stage.demo.actor.global_position.x
    Input.action_press("sk_right")
    await physics(135)
    Input.action_release("sk_right")
    print("S29_DEBUG first x=",start_x," now x=",stage.demo.actor.global_position.x," y=",stage.demo.actor.global_position.y," velocity=",stage.demo.actor.velocity," floor=",stage.demo.actor.is_on_floor())
    var sample=stage.s29_camera_diagnostics()
    verify(stage.demo.actor.global_position.x > start_x+350,"extended traversal reaches past S28 edge")
    verify(stage.demo.actor.is_on_floor(),"continuous ground supports running")
    verify(sample.lookahead_x > 25 and sample.lookahead_x <= 66.01,"rightward bounded look-ahead")
    verify(stage.demo.adapter.pose_geometry_verified(),"running geometry")
    verify(stage.demo.art_driver.is_visual_valid(),"running artwork")
    verify(sample.ground_sections==4,"extended corridor documented")
    verify(sample.raised_platform_sections==3,"bright collision platforms documented")
    for i in range(3): verify(sample.parallax_scales[i]<sample.parallax_scales[i+1],"ordered parallax "+str(i))
    Input.action_press("sk_left")
    await physics(28)
    Input.action_release("sk_left")
    verify(stage.s29_camera_diagnostics().lookahead_x < 0,"look-ahead reverses direction")
    Input.action_press("sk_crouch")
    await physics(6)
    verify(stage.demo.adapter.crouched,"input crouch preserved")
    verify(stage.demo.adapter.pose_geometry_verified(),"crouching geometry")
    Input.action_release("sk_crouch")
    await physics(15)
    verify(not stage.demo.adapter.crouched,"standing recovery")
    verify(stage.demo.adapter.visual.pose_texture_verified(),"standing texture verified")
    print("S29_TRAVERSAL_RESULT assertions=",checks," failures=",failures)
    quit(0 if failures==0 else 1)
func _initialize() -> void: call_deferred("run")

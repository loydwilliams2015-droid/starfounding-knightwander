extends SceneTree
const SCENE = preload("res://scenes/sk_pose_demo.tscn")
var passed := 0
var failed := 0
func _initialize() -> void: call_deferred("run")
func check(ok: bool, description: String) -> void:
    if ok: passed += 1
    else:
        failed += 1
        push_error("S23 " + description)
func tick(n: int) -> void:
    for i in range(n): await physics_frame
func run() -> void:
    var demo = SCENE.instantiate()
    root.add_child(demo)
    current_scene = demo
    await tick(4)
    var d: SKS23VisualDriver = demo.art_driver
    var a: SKCrouchAdapter = demo.adapter
    check(d.is_visual_valid(), "initial visual integrity")
    check(d.overlay.get_parent() == demo.actor, "overlay must not inherit hidden parent sprite alpha")
    check(d.overlay.modulate.a > 0.99 and d.source_sprite.modulate.a < 0.01, "only source is hidden; rendered overlay is opaque")
    check(d.phase == 0, "starts standing")
    Input.action_press("sk_crouch")
    await tick(3)
    check(a.crouched, "real input requests crouch")
    check(d.phase > 0 and d.phase < 7, "transition contains intermediate key pose")
    check(d.is_visual_valid(), "intermediate pose valid")
    await tick(12)
    check(d.phase == 7, "settles in final crouch")
    check(d.overlay.texture == d.PROFILE.CROUCH, "rendered crouch uses dedicated art")
    check(a.pose_geometry_verified(), "collision authority preserved")
    Input.action_press("sk_left")
    await tick(3)
    check(d.overlay.flip_h, "mirrors leftward input")
    check(d.is_visual_valid(), "mirrored pose integrity")
    Input.action_release("sk_left")
    demo.actor.global_position = Vector2(650,450)
    demo.actor.velocity = Vector2.ZERO
    await tick(4)
    Input.action_release("sk_crouch")
    await tick(4)
    check(a.stand_blocked and a.crouched, "ceiling blocks standing")
    check(d.phase == 7, "blocked standing never starts stand art")
    check(d.overlay.texture == d.PROFILE.CROUCH, "blocked state keeps crouch texture")
    Input.action_press("sk_left")
    await tick(95)
    Input.action_release("sk_left")
    await tick(12)
    check(not a.crouched, "exiting roof returns to stand")
    check(d.phase == 0, "reverse animation reaches standing")
    check(d.is_visual_valid(), "restored standing visual integrity")
    check(a.pose_geometry_verified(), "standing collider unchanged")
    for action in ["sk_crouch", "sk_left", "sk_right", "sk_jump"]: Input.action_release(action)
    print("S23_RESULT PASS ",passed," assertions" if failed == 0 else " FAILED "+str(failed))
    quit(0 if failed == 0 else 1)

extends SceneTree
const SCENE = preload("res://scenes/sk_s25_visual_reintegration.tscn")
const OUT := "res://captures/s27_engine/"
func frames(n:int) -> void:
    for i in range(n): await process_frame
func run() -> void:
    var scene = SCENE.instantiate()
    root.add_child(scene)
    current_scene = scene
    await frames(14)
    scene.set_preview(340.0,true,1.0)
    scene.set_readability_mode(true)
    scene.set_surface_separation(true)
    var failed := 0
    for mode in [false,true]:
        for i in range(8):
            scene.set_camera_tracking_phase(float(i) * 5.25,mode)
            await frames(3)
            var im := root.get_texture().get_image()
            var fname := ("snap_" if mode else "fractional_") + "%02d"%i + ".png"
            var err := im.save_png(ProjectSettings.globalize_path(OUT+fname))
            if err != OK or im.get_width() != 960 or im.get_height() != 540: failed += 1
            print("S27_CAPTURE ",fname," error=",err)
    quit(0 if failed == 0 else 1)
func _initialize() -> void: call_deferred("run")

from pathlib import Path
import hashlib, re
from PIL import Image
root=Path(__file__).resolve().parents[1]
def validate():
    a=Image.open(root/'assets/knight_standing.png').convert('RGBA')
    b=Image.open(root/'assets/knight_crouching.png').convert('RGBA')
    assert a.size==(64,128) and b.size==(64,80)
    assert hashlib.sha256(a.tobytes()).digest()!=hashlib.sha256(b.tobytes()).digest()
    for name, img in [('standing',a),('crouch',b)]:
        bounds=img.getchannel('A').getbbox()
        assert bounds is not None and bounds[3] >= img.height - 6, (name,bounds)
        assert bounds[2]-bounds[0] <= 64
        print('PASS',name,'RGBA',img.size,'visible bounds',bounds)
    visual=(root/'scripts/sk_pose_visual.gd').read_text()
    adapter=(root/'scripts/sk_crouch_adapter.gd').read_text()
    demo=(root/'scripts/sk_demo_world.gd').read_text()
    assert 'texture = crouching_texture if crouched else standing_texture' in visual
    assert 'scale = Vector2.ONE' in visual
    assert 'offset = Vector2(0.0, -texture.get_height() * 0.5)' in visual
    assert 'standing_height: float = 120.0' in adapter
    assert 'crouched_height: float = 67.2' in adapter
    assert 'body.global_transform * Transform2D' in adapter
    assert 'q.exclude = [body.get_rid()]' in adapter
    assert 'if not want_crouch and not _can_stand():' in adapter
    assert 'adapter.request_crouch(holding)' in demo
    assert 'get_tree().reload_current_scene()' in demo
    assert (root/'scenes/sk_pose_demo.tscn').exists()
    print('PASS source contracts, clearance query, anchored textures, integration harness')
if __name__=='__main__': validate()

extends SceneTree
## Scripted engine-rendered motion study, NOT a capture of actual player input.
const TEX = [preload("res://assets/knight_standing.png"), preload("res://assets/knight_transition_settle.png"), preload("res://assets/knight_transition_compress.png"), preload("res://assets/knight_crouching.png")]
const POSE = [0,0,1,2,3,3,3,3,3,3,2,1,0,0]
const NAMES = ["stand","settle","compress","crouch"]
var sprites: Array[Sprite2D] = []
var labels: Array[Label] = []
var saved := 0
func _initialize() -> void: call_deferred("run")
func label_on(parent: Node, message: String, pos: Vector2, size: int) -> Label:
    var l := Label.new()
    l.position=pos
    l.text=message
    l.add_theme_font_size_override("font_size",size)
    parent.add_child(l)
    return l
func rectangle(parent: Node, x: float, y: float, width: float, height: float, tint: Color) -> void:
    var poly := Polygon2D.new()
    poly.color=tint
    poly.polygon=PackedVector2Array([Vector2(x,y),Vector2(x+width,y),Vector2(x+width,y+height),Vector2(x,y+height)])
    parent.add_child(poly)
func run() -> void:
    root.content_scale_size = Vector2i(960,540)
    var scene := Node2D.new()
    root.add_child(scene)
    current_scene=scene
    for panel_id in range(2):
        var pane := Node2D.new()
        pane.position = Vector2(panel_id * 480,0)
        scene.add_child(pane)
        rectangle(pane,0,0,480,540,Color("253642") if panel_id == 0 else Color("57636c"))
        rectangle(pane,0,410,480,8,Color("a5b7b7"))
        for j in range(1,6):
            rectangle(pane,j*80,420,2,80,Color("8c9ea6") if panel_id == 0 else Color("3e4a55"))
        label_on(pane,["S15 / A  :  moving poses","S15 / A  :  mirrored poses"][panel_id],Vector2(17,20),21)
        label_on(pane,"Original SK reference sprites",Vector2(17,54),15)
        labels.append(label_on(pane,"",Vector2(17,462),17))
        var knight := Sprite2D.new()
        knight.centered=true
        knight.texture_filter=CanvasItem.TEXTURE_FILTER_NEAREST
        pane.add_child(knight)
        sprites.append(knight)
    DirAccess.make_dir_recursive_absolute(ProjectSettings.globalize_path("res://captures/s15_engine"))
    for i in range(POSE.size()):
        for panel_id in range(2):
            var knight := sprites[panel_id]
            knight.texture=TEX[POSE[i]]
            knight.offset=Vector2(0.0,-float(knight.texture.get_height())*0.5)
            knight.flip_h=(panel_id == 1)
            knight.scale=Vector2.ONE
            var distance: float=float(i if i <= 8 else 16-i)*15.0
            knight.position=Vector2(135.0+distance if panel_id == 0 else 345.0-distance,410.0)
            labels[panel_id].text="%02d  %s | feet Y=410 | X=%.0f" % [i,NAMES[POSE[i]],knight.position.x]
        for j in range(2): await process_frame
        await RenderingServer.frame_post_draw
        var screenshot:=root.get_viewport().get_texture().get_image()
        var err:=screenshot.save_png("res://captures/s15_engine/frame_%02d.png" % i)
        if err != OK:
            push_error("S15 frame capture failed: %s" % err)
            quit(1)
            return
        saved+=1
    print("S15_CAPTURE_RESULT PASS ",saved," frames")
    quit(0)

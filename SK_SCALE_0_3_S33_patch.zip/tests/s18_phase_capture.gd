extends SceneTree
## Controlled pixel-phase and background-contrast captures. Actor and pose remain fixed.
const SCENE = preload("res://scenes/sk_pose_demo.tscn")
const ZOOMS = [1.0, 1.5, 2.0]
const PHASES = [0.0, 0.25, 0.5, 0.75]
const BACKS = [Color("18252b"), Color("8c9190")]
var count := 0
func _initialize() -> void: call_deferred("run")
func run() -> void:
    root.content_scale_size = Vector2i(960,540)
    var demo = SCENE.instantiate()
    root.add_child(demo)
    current_scene = demo
    for i in 5: await physics_frame
    demo.set_physics_process(false)
    demo.set_process(false)
    var actor: CharacterBody2D = demo.actor
    var adapter: SKCrouchAdapter = demo.adapter
    actor.velocity = Vector2.ZERO
    actor.global_position = Vector2(190,450)
    adapter.request_crouch(true)
    var camera := Camera2D.new()
    demo.add_child(camera)
    camera.make_current()
    camera.position_smoothing_enabled = false
    var bg := ColorRect.new()
    bg.set_anchors_preset(Control.PRESET_FULL_RECT)
    bg.size = Vector2(960,540)
    var layer := CanvasLayer.new()
    layer.layer = -10
    demo.add_child(layer)
    layer.add_child(bg)
    # Hide stage geometry, not the character; test the silhouette on flat backgrounds.
    for node in demo.get_children():
        if node is StaticBody2D:
            node.visible = false
    demo.hud.visible = false
    DirAccess.make_dir_recursive_absolute(ProjectSettings.globalize_path("res://captures/s18_engine"))
    for b in BACKS.size():
        bg.color = BACKS[b]
        for z in ZOOMS:
            camera.zoom = Vector2(z,z)
            for p in PHASES:
                camera.global_position = actor.global_position + Vector2(p,-60.0)
                if not adapter.crouched or not adapter.visual.pose_texture_verified() or not adapter.pose_geometry_verified():
                    push_error("S18 pose contract failed")
                    quit(1)
                    return
                await process_frame
                await RenderingServer.frame_post_draw
                var im := root.get_viewport().get_texture().get_image()
                var name := "res://captures/s18_engine/contrast_%d_zoom_%03d_phase_%02d.png" % [b,roundi(z*100),roundi(p*100)]
                if im.get_width()!=960 or im.get_height()!=540 or im.save_png(name)!=OK:
                    push_error("S18 capture failed: "+name)
                    quit(1)
                    return
                count += 1
    print("S18_PHASE_CAPTURE PASS %d" % count)
    quit(0)

extends SceneTree
const SCENE = preload("res://scenes/sk_s25_visual_reintegration.tscn")
const OUT = "res://captures/s29_engine/"
func physics(n:int) -> void:
    for i in range(n): await physics_frame
func frames(n:int) -> void:
    for i in range(n): await process_frame
func capture(stage,label:String)->int:
    await frames(3)
    var image=root.get_texture().get_image()
    var err=image.save_png(ProjectSettings.globalize_path(OUT+label+".png"))
    print("S29_FRAME ",label," x=",stage.demo.actor.global_position.x," offset=",stage.camera.offset.x," err=",err)
    return 0 if err==OK and image.get_size()==Vector2i(960,540) else 1
func run()->void:
    var stage=SCENE.instantiate()
    root.add_child(stage)
    current_scene=stage
    await frames(15)
    stage.set_readability_mode(true)
    stage.set_surface_separation(true)
    stage.demo.actor.global_position=Vector2(1030,450)
    stage.demo.actor.velocity=Vector2.ZERO
    await physics(6)
    var errors=await capture(stage,"01_start")
    Input.action_press("sk_right")
    for i in range(7):
        await physics(22)
        errors+=await capture(stage,"%02d_running"%(i+2))
    Input.action_release("sk_right")
    Input.action_press("sk_left")
    for i in range(3):
        await physics(12)
        errors+=await capture(stage,"%02d_reversing"%(i+9))
    Input.action_release("sk_left")
    Input.action_press("sk_crouch")
    await physics(6)
    errors+=await capture(stage,"12_crouch")
    Input.action_release("sk_crouch")
    await physics(10)
    errors+=await capture(stage,"13_recovered")
    print("S29_CAPTURE_RESULT errors=",errors)
    quit(0 if errors==0 else 1)
func _initialize()->void:call_deferred("run")

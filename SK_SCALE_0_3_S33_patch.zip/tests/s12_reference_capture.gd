extends SceneTree
## Reference-informed comparative viewing conditions, not reproduction of other games.
const STAND = preload("res://assets/knight_standing.png")
const CROUCH = preload("res://assets/knight_crouching.png")
var errors: Array[String] = []
var stage: Node2D
var camera: Camera2D
func _initialize() -> void: call_deferred("run")
func _text(parent: Node, label: String, position: Vector2, size: int = 18) -> void:
    var t := Label.new()
    t.text = label
    t.position = position
    t.add_theme_font_size_override("font_size", size)
    parent.add_child(t)
func _sprite(texture: Texture2D, x: float, floor_y: float) -> void:
    var sprite := Sprite2D.new()
    sprite.texture = texture
    sprite.position = Vector2(x, floor_y)
    sprite.offset = Vector2(0, -float(texture.get_height()) * 0.5)
    sprite.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
    stage.add_child(sprite)
func _panel(x: float, color: Color) -> void:
    var bg := Polygon2D.new()
    bg.polygon = PackedVector2Array([Vector2(x,0),Vector2(x+320,0),Vector2(x+320,540),Vector2(x,540)])
    bg.color = color
    stage.add_child(bg)
func _capture(filename: String) -> void:
    await RenderingServer.frame_post_draw
    var im := root.get_viewport().get_texture().get_image()
    if im.get_size() != Vector2i(960,540) or im.save_png("res://captures/s12_engine/"+filename+".png") != OK:
        errors.append(filename)
    else:
        print("CAPTURED ",filename)
func run() -> void:
    root.content_scale_size = Vector2i(960,540)
    var holder := Node2D.new()
    root.add_child(holder)
    current_scene = holder
    DirAccess.make_dir_recursive_absolute(ProjectSettings.globalize_path("res://captures/s12_engine"))
    stage = Node2D.new()
    holder.add_child(stage)
    _panel(0, Color("23303b"))
    _panel(320, Color("3a4651"))
    _panel(640, Color("526678"))
    for x in [160.0,480.0,800.0]:
        _sprite(STAND,x-48,382)
        _sprite(CROUCH,x+48,382)
    var canvas := CanvasLayer.new()
    holder.add_child(canvas)
    _text(canvas,"S12  |  ORIGINAL SK SPRITES  |  IN-ENGINE READABILITY REVIEW",Vector2(24,14),21)
    for i in range(3):
        _text(canvas,["DARK / silhouette", "MID / costume", "LIGHT / contrast"][i],Vector2(i*320+35,90),17)
        _text(canvas,"1:1 native texture | feet aligned",Vector2(i*320+20,420),14)
    _text(canvas,"Study: Mega Man X4 pose discipline + Dead Cells production economy. NOT copied art.",Vector2(24,500),15)
    for n in range(3): await process_frame
    await _capture("01_reference_contrast")
    # More crowded framing stress-tests readability, source sprite dimensions unchanged.
    for x in [80.0,240.0,400.0,560.0,720.0,880.0]:
        _sprite(CROUCH,x,470)
    _text(canvas,"Density test: 6 additional crouch silhouettes",Vector2(24,463),16)
    for n in range(3): await process_frame
    await _capture("02_reference_density")
    print("S12_CAPTURE_RESULT ","PASS" if errors.is_empty() else "FAIL", " ",2-errors.size()," screenshots")
    quit(0 if errors.is_empty() else 1)

extends SceneTree
## S11: Godot-rendered screenshot sequence. Input actions drive transitions.
## Position is staged only for low-roof entry, not for crouch or stand transitions.
const SCENE = preload("res://scenes/sk_pose_demo.tscn")
var errors: Array[String] = []
var shots := 0
func _initialize() -> void: call_deferred("run")
func frames(n: int) -> void:
    for i in range(n): await physics_frame
func snap(demo: Node2D, filename: String, heading: String, expect_crouch: bool, expect_blocked: bool) -> void:
    var pose: SKCrouchAdapter = demo.adapter
    var art: SKPoseVisual = pose.visual
    if pose.crouched != expect_crouch or pose.stand_blocked != expect_blocked or not art.pose_texture_verified():
        errors.append("Contract mismatch " + filename)
    demo.hud.text = "SK SCALE/ART S11 | NATIVE GODOT CAPTURE\n%s\nPose: %s | Stand blocked: %s | X: %.1f\nAssigned texture: %s\nAction-driven QA / reference artwork (NOT approved art)" % [heading, "CROUCH" if pose.crouched else "STAND", str(pose.stand_blocked), demo.actor.global_position.x, art.current_asset_path()]
    await process_frame
    await RenderingServer.frame_post_draw
    var im := demo.get_viewport().get_texture().get_image()
    var filepath := "res://captures/s11_engine/" + filename + ".png"
    if im.is_empty() or im.get_size() != Vector2i(960,540) or im.save_png(filepath) != OK:
        errors.append("Capture failed " + filename)
    else:
        shots += 1
        print("CAPTURED ", filepath)
func run() -> void:
    var demo := SCENE.instantiate()
    root.add_child(demo)
    current_scene = demo
    DirAccess.make_dir_recursive_absolute(ProjectSettings.globalize_path("res://captures/s11_engine"))
    await frames(5)
    await snap(demo,"01_stand","Standing | input idle",false,false)
    Input.action_press("sk_crouch")
    await frames(4)
    await snap(demo,"02_crouch","Crouch action held",true,false)
    Input.action_press("sk_right")
    await frames(30)
    Input.action_release("sk_right")
    await snap(demo,"03_crouch_walk","30 physics frames of crouched rightward movement",true,false)
    demo.actor.global_position = Vector2(650,450) # Explicitly staged start under the test roof.
    demo.actor.velocity = Vector2.ZERO
    await frames(4)
    Input.action_release("sk_crouch")
    await frames(4)
    await snap(demo,"04_blocked","Released crouch under roof: blocked",true,true)
    Input.action_press("sk_crouch")
    Input.action_press("sk_left")
    await frames(55)
    await snap(demo,"05_exiting","Held crouch + left action exiting roof",true,false)
    await frames(40)
    Input.action_release("sk_left")
    Input.action_release("sk_crouch")
    await frames(4)
    await snap(demo,"06_recovered","Released crouch in clear air: standing",false,false)
    for action in ["sk_crouch", "sk_left", "sk_right", "sk_jump"]: Input.action_release(action)
    print("S11_CAPTURE_RESULT ", "PASS" if errors.is_empty() else "FAIL", " ", shots, " frames ", errors)
    quit(0 if errors.is_empty() else 1)

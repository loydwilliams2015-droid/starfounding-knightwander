extends SceneTree
const SCENE = preload("res://scenes/sk_s25_visual_reintegration.tscn")
const OUT = "res://captures/s28_engine/"
func frames(n:int) -> void:
    for i in range(n): await process_frame
func physics(n:int) -> void:
    for i in range(n): await physics_frame
func capture(stage, label:String) -> int:
    await frames(3)
    var img = root.get_texture().get_image()
    var err = img.save_png(ProjectSettings.globalize_path(OUT+label+".png"))
    print("S28_CAPTURE ",label," actor=",stage.demo.actor.global_position," crouch=",stage.demo.adapter.crouched," err=",err)
    return 0 if err==OK and img.get_size()==Vector2i(960,540) else 1
func run() -> void:
    var stage = SCENE.instantiate()
    root.add_child(stage)
    current_scene=stage
    await frames(15)
    stage.set_readability_mode(true)
    stage.set_surface_separation(true)
    var failures:=0
    stage.demo.actor.global_position = Vector2(220,450)
    await physics(5)
    failures += await capture(stage,"01_standing")
    Input.action_press("sk_right")
    for i in range(4):
        await physics(8)
        failures += await capture(stage,"%02d_running"%(i+2))
    Input.action_release("sk_right")
    stage.demo.actor.global_position=Vector2(250,450)
    stage.demo.actor.velocity=Vector2.ZERO
    await physics(6)
    stage.demo.jump_queued=true
    for i in range(4):
        await physics(4)
        failures += await capture(stage,"%02d_jumping"%(i+6))
    await physics(65)
    stage.demo.actor.global_position=Vector2(270,450)
    stage.demo.actor.velocity=Vector2.ZERO
    await physics(5)
    Input.action_press("sk_crouch")
    Input.action_press("sk_right")
    for i in range(4):
        await physics(6)
        failures += await capture(stage,"%02d_crouch_run"%(i+10))
    Input.action_release("sk_right")
    Input.action_release("sk_crouch")
    await physics(12)
    failures += await capture(stage,"14_recovered")
    print("S28_CAPTURE_RESULT failures=",failures)
    quit(0 if failures==0 else 1)
func _initialize() -> void: call_deferred("run")

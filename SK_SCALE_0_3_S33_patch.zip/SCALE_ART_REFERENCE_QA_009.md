# SCALE/ART QA-009 — S20 silhouette continuity and gameplay-scale review

Append-only amendment. Profile A (Mega Man X4-inspired purposeful key poses) remains preferred, with Dead Cells-style continuity used selectively. S18 baseline, S19 wider trial, and S20 narrower experimental trial coexist. No copyrighted reference-game sprite assets are included.

## Technical gates
- Distinct authored textures, no texture squashing, shared foot anchor, nearest filter, stable facing and authoritative collision unchanged.
- Check silhouette widths and horizontal centroids from transparent-source PNGs, with results retained in `s20_silhouette_metrics.json`.
- Compare all three candidates at 1× (primary) and 2× (inspection) on dark and medium backgrounds.
- Neither relative width nor foot anchoring alone proves convincing anatomy or motion; human acceptance must inspect hip/knee/ankle articulation and torso/equipment continuity.

## Promotion gate
A candidate may not replace the original project's animation art until visual review and integration into the original playable SK project are completed. A native Godot QA capture is evidence of the standalone scene only. 2× presentation enlargement is camera-review-only; actor sprites stay 1:1 in the control logic.
